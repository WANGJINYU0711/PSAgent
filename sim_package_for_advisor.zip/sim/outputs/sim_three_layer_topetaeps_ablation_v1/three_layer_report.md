# Three-layer top eta/eps sim ablation

## Setting

- output_dir: `/home/ubuntu/data/PSAgent/outputs/sim_three_layer_topetaeps_ablation_v1`
- tree_spec: `/home/ubuntu/data/PSAgent/analysis/tree_specs/shared_basin_strong_4of5_prefix_dedup.json`
- eta_values: `[0.2, 0.3, 0.4]`
- epsilon_values: `[0.005, 0.01, 0.02]`
- horizon: `1000`
- seeds: `[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]`
- methods: `13`
- completed combo rows: `117` / `117`
- PS-winning combos by post-switch: `29` / `117`

Primary ranking: post_switch_avg_regret_mean, then tail20_avg_total_cost_mean, then regret_per_t_mean.

## sim_v10_d2_4_top3_etaeps_full13_v1

补齐 v10 single-switch d=2,3,4；不重复已跑过的 d=5,6。

- cost_mode: `ps_favored_trap_v10_avg_baited`
- control_kind: `d`
- control_values: `[2, 3, 4]`
- combos: `27`
- PS-winning combos: `12` / `27`

### Top PS-winning configs

| experiment_name | control_kind | control_value | eta | epsilon | best_post_method | best_post_value | best_ps_method | best_ps_post_rank | best_ps_post_value | ps_minus_best_nonps_post | best_nonps_method | ps_minus_direct_multistage_exp3_post | ps_minus_direct_multistage_exp3_local_post | ps_minus_epsilon_exp3_post | ps_minus_naive_mixed_avg_post | best_ps_regret_per_t | best_ps_tail20 | best_ps_target_good_fraction | best_ps_trap_basin_fraction | best_ps_shared_path_fraction | best_ps_exact_hit |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| sim_v10_d2_4_top3_etaeps_full13_v1 | d | 4 | 0.300000 | 0.010000 | risky_ps_old | 0.078400 | risky_ps_old | 1 | 0.078400 | -0.019467 | direct_multistage_exp3 | -0.019467 | -0.036667 | -0.026133 | -0.056933 | 0.066184 | 0.015000 | 0.728600 | 0.045600 | 0.989300 | 0.378400 |
| sim_v10_d2_4_top3_etaeps_full13_v1 | d | 4 | 0.300000 | 0.020000 | risky_ps_old | 0.086533 | risky_ps_old | 1 | 0.086533 | -0.011333 | direct_multistage_exp3 | -0.011333 | -0.028533 | -0.021600 | -0.048800 | 0.073284 | 0.030000 | 0.713200 | 0.054300 | 0.986000 | 0.350900 |
| sim_v10_d2_4_top3_etaeps_full13_v1 | d | 3 | 0.400000 | 0.005000 | risky_ps_old | 0.098246 | risky_ps_old | 1 | 0.098246 | -0.034183 | direct_multistage_exp3_local | -0.080510 | -0.034183 | -0.069865 | -0.067616 | 0.066330 | 0.045000 | 0.655700 | 0.066000 | 0.986100 | 0.380600 |
| sim_v10_d2_4_top3_etaeps_full13_v1 | d | 4 | 0.400000 | 0.005000 | risky_ps_old | 0.099467 | risky_ps_old | 1 | 0.099467 | -0.009467 | direct_multistage_exp3 | -0.009467 | -0.020667 | -0.016400 | -0.035867 | 0.079584 | 0.030000 | 0.704900 | 0.056300 | 0.986600 | 0.276800 |
| sim_v10_d2_4_top3_etaeps_full13_v1 | d | 3 | 0.400000 | 0.010000 | risky_ps_old | 0.107391 | risky_ps_old | 1 | 0.107391 | -0.016942 | epsilon_exp3 | -0.071364 | -0.025037 | -0.016942 | -0.058471 | 0.072630 | 0.015000 | 0.647700 | 0.061600 | 0.986200 | 0.262600 |
| sim_v10_d2_4_top3_etaeps_full13_v1 | d | 3 | 0.300000 | 0.010000 | risky_ps_old | 0.108741 | risky_ps_old | 1 | 0.108741 | -0.014993 | direct_multistage_exp3 | -0.014993 | -0.059670 | -0.044828 | -0.057121 | 0.075430 | 0.025000 | 0.645500 | 0.062700 | 0.985900 | 0.365400 |
| sim_v10_d2_4_top3_etaeps_full13_v1 | d | 3 | 0.300000 | 0.020000 | risky_ps_old | 0.113238 | risky_ps_old | 1 | 0.113238 | -0.010495 | direct_multistage_exp3 | -0.010495 | -0.055172 | -0.047676 | -0.052624 | 0.081130 | 0.035000 | 0.636200 | 0.063400 | 0.985300 | 0.246100 |
| sim_v10_d2_4_top3_etaeps_full13_v1 | d | 2 | 0.400000 | 0.010000 | risky_ps_old | 0.126600 | risky_ps_old | 1 | 0.126600 | -0.040000 | direct_multistage_exp3_local | -0.100000 | -0.040000 | -0.071000 | -0.173800 | 0.054668 | 0.030000 | 0.527000 | 0.067300 | 0.986500 | 0.206200 |
| sim_v10_d2_4_top3_etaeps_full13_v1 | d | 2 | 0.400000 | 0.005000 | risky_ps_old | 0.157000 | risky_ps_old | 1 | 0.157000 | -0.009600 | direct_multistage_exp3_local | -0.069600 | -0.009600 | -0.071000 | -0.143400 | 0.071068 | 0.105000 | 0.503700 | 0.075800 | 0.982800 | 0.194600 |
| sim_v10_d2_4_top3_etaeps_full13_v1 | d | 2 | 0.300000 | 0.010000 | risky_ps_old | 0.157600 | risky_ps_old | 1 | 0.157600 | -0.040200 | direct_multistage_exp3_local | -0.076200 | -0.040200 | -0.085600 | -0.142800 | 0.072768 | 0.020000 | 0.510000 | 0.080800 | 0.984600 | 0.236400 |
| sim_v10_d2_4_top3_etaeps_full13_v1 | d | 2 | 0.300000 | 0.020000 | risky_ps_old | 0.161200 | risky_ps_old | 1 | 0.161200 | -0.036600 | direct_multistage_exp3_local | -0.072600 | -0.036600 | -0.093400 | -0.139200 | 0.077868 | 0.050000 | 0.503700 | 0.087900 | 0.983100 | 0.182200 |
| sim_v10_d2_4_top3_etaeps_full13_v1 | d | 2 | 0.300000 | 0.005000 | risky_ps_old | 0.192400 | risky_ps_old | 1 | 0.192400 | -0.005400 | direct_multistage_exp3_local | -0.041400 | -0.005400 | -0.027400 | -0.108000 | 0.090568 | 0.020000 | 0.474300 | 0.081300 | 0.983200 | 0.137700 |

### Top configs across all methods

| experiment_name | control_kind | control_value | eta | epsilon | best_post_method | best_post_value | best_ps_method | best_ps_post_rank | best_ps_post_value | ps_minus_best_nonps_post | best_nonps_method | ps_minus_direct_multistage_exp3_post | ps_minus_direct_multistage_exp3_local_post | ps_minus_epsilon_exp3_post | ps_minus_naive_mixed_avg_post | best_ps_regret_per_t | best_ps_tail20 | best_ps_target_good_fraction | best_ps_trap_basin_fraction | best_ps_shared_path_fraction | best_ps_exact_hit |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| sim_v10_d2_4_top3_etaeps_full13_v1 | d | 4 | 0.300000 | 0.010000 | risky_ps_old | 0.078400 | risky_ps_old | 1 | 0.078400 | -0.019467 | direct_multistage_exp3 | -0.019467 | -0.036667 | -0.026133 | -0.056933 | 0.066184 | 0.015000 | 0.728600 | 0.045600 | 0.989300 | 0.378400 |
| sim_v10_d2_4_top3_etaeps_full13_v1 | d | 4 | 0.400000 | 0.010000 | epsilon_exp3 | 0.085467 | risky_ps_old | 3 | 0.109200 | 0.023733 | epsilon_exp3 | 0.000267 | -0.010933 | 0.023733 | -0.026133 | 0.086784 | 0.045000 | 0.699300 | 0.054300 | 0.987500 | 0.308900 |
| sim_v10_d2_4_top3_etaeps_full13_v1 | d | 4 | 0.300000 | 0.020000 | risky_ps_old | 0.086533 | risky_ps_old | 1 | 0.086533 | -0.011333 | direct_multistage_exp3 | -0.011333 | -0.028533 | -0.021600 | -0.048800 | 0.073284 | 0.030000 | 0.713200 | 0.054300 | 0.986000 | 0.350900 |
| sim_v10_d2_4_top3_etaeps_full13_v1 | d | 4 | 0.200000 | 0.020000 | epsilon_exp3 | 0.096533 | risky_ps_old | 3 | 0.106933 | 0.010400 | epsilon_exp3 | 0.006133 | -0.058667 | 0.010400 | -0.028400 | 0.091084 | 0.045000 | 0.690800 | 0.067000 | 0.983800 | 0.279600 |
| sim_v10_d2_4_top3_etaeps_full13_v1 | d | 4 | 0.300000 | 0.005000 | direct_multistage_exp3 | 0.097867 | risky_ps_linear | 4 | 0.124933 | 0.027067 | direct_multistage_exp3 | 0.027067 | 0.009867 | 0.016000 | -0.010400 | 0.101184 | 0.025000 | 0.683300 | 0.050700 | 0.985600 | 0.296300 |
| sim_v10_d2_4_top3_etaeps_full13_v1 | d | 3 | 0.400000 | 0.005000 | risky_ps_old | 0.098246 | risky_ps_old | 1 | 0.098246 | -0.034183 | direct_multistage_exp3_local | -0.080510 | -0.034183 | -0.069865 | -0.067616 | 0.066330 | 0.045000 | 0.655700 | 0.066000 | 0.986100 | 0.380600 |
| sim_v10_d2_4_top3_etaeps_full13_v1 | d | 4 | 0.400000 | 0.005000 | risky_ps_old | 0.099467 | risky_ps_old | 1 | 0.099467 | -0.009467 | direct_multistage_exp3 | -0.009467 | -0.020667 | -0.016400 | -0.035867 | 0.079584 | 0.030000 | 0.704900 | 0.056300 | 0.986600 | 0.276800 |
| sim_v10_d2_4_top3_etaeps_full13_v1 | d | 4 | 0.200000 | 0.010000 | direct_multistage_exp3 | 0.100800 | risky_ps_old | 2 | 0.100800 | 0.000000 | direct_multistage_exp3 | 0.000000 | -0.064800 | -0.003600 | -0.034533 | 0.086484 | 0.020000 | 0.698200 | 0.061800 | 0.985800 | 0.352200 |
| sim_v10_d2_4_top3_etaeps_full13_v1 | d | 4 | 0.200000 | 0.005000 | direct_multistage_exp3 | 0.100800 | risky_ps_old | 3 | 0.109600 | 0.008800 | direct_multistage_exp3 | 0.008800 | -0.056000 | 0.007867 | -0.025733 | 0.092684 | 0.015000 | 0.702400 | 0.053600 | 0.987000 | 0.300000 |
| sim_v10_d2_4_top3_etaeps_full13_v1 | d | 4 | 0.400000 | 0.020000 | epsilon_exp3 | 0.103467 | risky_ps_linear | 5 | 0.172933 | 0.069467 | epsilon_exp3 | 0.064000 | 0.052800 | 0.069467 | 0.037600 | 0.135784 | 0.180000 | 0.640300 | 0.045600 | 0.986200 | 0.206200 |
| sim_v10_d2_4_top3_etaeps_full13_v1 | d | 3 | 0.200000 | 0.005000 | direct_multistage_exp3 | 0.103943 | risky_ps_old | 3 | 0.123283 | 0.019340 | direct_multistage_exp3 | 0.019340 | -0.064168 | 0.002249 | -0.042579 | 0.088830 | 0.030000 | 0.633200 | 0.068800 | 0.985200 | 0.305100 |
| sim_v10_d2_4_top3_etaeps_full13_v1 | d | 3 | 0.200000 | 0.010000 | direct_multistage_exp3 | 0.103943 | risky_ps_old | 2 | 0.125532 | 0.021589 | direct_multistage_exp3 | 0.021589 | -0.061919 | -0.001049 | -0.040330 | 0.091830 | 0.020000 | 0.626200 | 0.077500 | 0.983500 | 0.327900 |
| sim_v10_d2_4_top3_etaeps_full13_v1 | d | 3 | 0.200000 | 0.020000 | direct_multistage_exp3 | 0.103943 | risky_ps_old | 2 | 0.128531 | 0.024588 | direct_multistage_exp3 | 0.024588 | -0.058921 | -0.007646 | -0.037331 | 0.093530 | 0.015000 | 0.609400 | 0.082900 | 0.981700 | 0.271700 |
| sim_v10_d2_4_top3_etaeps_full13_v1 | d | 3 | 0.400000 | 0.010000 | risky_ps_old | 0.107391 | risky_ps_old | 1 | 0.107391 | -0.016942 | epsilon_exp3 | -0.071364 | -0.025037 | -0.016942 | -0.058471 | 0.072630 | 0.015000 | 0.647700 | 0.061600 | 0.986200 | 0.262600 |
| sim_v10_d2_4_top3_etaeps_full13_v1 | d | 3 | 0.300000 | 0.010000 | risky_ps_old | 0.108741 | risky_ps_old | 1 | 0.108741 | -0.014993 | direct_multistage_exp3 | -0.014993 | -0.059670 | -0.044828 | -0.057121 | 0.075430 | 0.025000 | 0.645500 | 0.062700 | 0.985900 | 0.365400 |
| sim_v10_d2_4_top3_etaeps_full13_v1 | d | 3 | 0.300000 | 0.020000 | risky_ps_old | 0.113238 | risky_ps_old | 1 | 0.113238 | -0.010495 | direct_multistage_exp3 | -0.010495 | -0.055172 | -0.047676 | -0.052624 | 0.081130 | 0.035000 | 0.636200 | 0.063400 | 0.985300 | 0.246100 |
| sim_v10_d2_4_top3_etaeps_full13_v1 | d | 3 | 0.400000 | 0.020000 | epsilon_exp3 | 0.120885 | risky_ps_linear | 5 | 0.194198 | 0.073313 | epsilon_exp3 | 0.015442 | 0.061769 | 0.073313 | 0.028336 | 0.131930 | 0.100000 | 0.577000 | 0.058300 | 0.982200 | 0.208300 |
| sim_v10_d2_4_top3_etaeps_full13_v1 | d | 3 | 0.300000 | 0.005000 | direct_multistage_exp3 | 0.123733 | risky_ps_linear | 3 | 0.137226 | 0.013493 | direct_multistage_exp3 | 0.013493 | -0.031184 | 0.011244 | -0.028636 | 0.094730 | 0.025000 | 0.616800 | 0.061100 | 0.984100 | 0.276700 |
| sim_v10_d2_4_top3_etaeps_full13_v1 | d | 2 | 0.400000 | 0.010000 | risky_ps_old | 0.126600 | risky_ps_old | 1 | 0.126600 | -0.040000 | direct_multistage_exp3_local | -0.100000 | -0.040000 | -0.071000 | -0.173800 | 0.054668 | 0.030000 | 0.527000 | 0.067300 | 0.986500 | 0.206200 |
| sim_v10_d2_4_top3_etaeps_full13_v1 | d | 2 | 0.200000 | 0.005000 | direct_multistage_exp3 | 0.145200 | risky_ps_old | 2 | 0.157600 | 0.012400 | direct_multistage_exp3 | 0.012400 | -0.063000 | -0.132400 | -0.142800 | 0.076168 | 0.010000 | 0.500600 | 0.087800 | 0.982600 | 0.260100 |

### Best by method, post-switch

| best_post_rank | method | control_value | eta_sweep | epsilon_sweep | post_switch_avg_regret_mean | tail20_avg_total_cost_mean | regret_per_t_mean | target_good_fraction_mean | trap_basin_fraction_mean | shared_path_fraction_mean | exact_best_path_hit_rate_mean |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | risky_ps_old | 4 | 0.300000 | 0.010000 | 0.078400 | 0.015000 | 0.066184 | 0.728600 | 0.045600 | 0.989300 | 0.378400 |
| 2 | epsilon_exp3 | 4 | 0.400000 | 0.010000 | 0.085467 | 0.035000 | 0.069684 | 0.715900 | 0.053500 | 0.988900 | 0.164700 |
| 3 | direct_multistage_exp3 | 4 | 0.300000 | 0.005000 | 0.097867 | 0.005000 | 0.079784 | 0.704800 | 0.081100 | 0.984400 | 0.347000 |
| 4 | risky_ps_linear | 4 | 0.300000 | 0.010000 | 0.099067 | 0.010000 | 0.081984 | 0.706100 | 0.048200 | 0.987000 | 0.373600 |
| 5 | risky_ps | 4 | 0.300000 | 0.010000 | 0.111067 | 0.030000 | 0.090884 | 0.696900 | 0.049200 | 0.988000 | 0.403600 |
| 6 | risky_ps_ix | 4 | 0.300000 | 0.010000 | 0.112133 | 0.015000 | 0.091684 | 0.695700 | 0.049200 | 0.988000 | 0.405900 |
| 7 | direct_multistage_exp3_local | 4 | 0.300000 | 0.005000 | 0.115067 | 0.005000 | 0.098084 | 0.682900 | 0.092700 | 0.980200 | 0.343600 |
| 8 | naive_mixed_avg | 4 | 0.200000 | 0.005000 | 0.135333 | 0.010000 | 0.090884 | 0.673000 | 0.000000 | 1.000000 | 0.183300 |
| 9 | risky_ps_safe_conditional | 4 | 0.300000 | 0.020000 | 0.144000 | 0.070000 | 0.116784 | 0.657000 | 0.054300 | 0.984700 | 0.304000 |
| 10 | risky_ps_safe_conditional_ix | 4 | 0.300000 | 0.010000 | 0.144267 | 0.015000 | 0.115184 | 0.664100 | 0.052400 | 0.986000 | 0.348000 |
| 11 | risky_ps_direct_cost | 3 | 0.200000 | 0.010000 | 0.410540 | 0.085000 | 0.280930 | 0.385200 | 0.086800 | 0.974400 | 0.163700 |
| 12 | random_path | 3 | 0.200000 | 0.005000 | 0.753118 | 0.755000 | 0.604330 | 0.072000 | 0.079200 | 0.929300 | 0.020600 |
| 13 | naive_mixed | 2 | 0.200000 | 0.005000 | 0.795200 | 0.905000 | 0.370168 | 0.087400 | 0.000000 | 1.000000 | 0.000000 |

## sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1

v11 cyclic switch_count=1..6 局部 eta/eps sweep。

- cost_mode: `ps_favored_trap_v11_cyclic_baited`
- control_kind: `switch_count`
- control_values: `[1, 2, 3, 4, 5, 6]`
- combos: `54`
- PS-winning combos: `17` / `54`

### Top PS-winning configs

| experiment_name | control_kind | control_value | eta | epsilon | best_post_method | best_post_value | best_ps_method | best_ps_post_rank | best_ps_post_value | ps_minus_best_nonps_post | best_nonps_method | ps_minus_direct_multistage_exp3_post | ps_minus_direct_multistage_exp3_local_post | ps_minus_epsilon_exp3_post | ps_minus_naive_mixed_avg_post | best_ps_regret_per_t | best_ps_tail20 | best_ps_target_good_fraction | best_ps_trap_basin_fraction | best_ps_shared_path_fraction | best_ps_exact_hit |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 3 | 0.400000 | 0.020000 | risky_ps_old | -0.247521 | risky_ps_old | 1 | -0.247521 | -0.011200 | direct_multistage_exp3 | -0.011200 | -0.044533 | -0.039200 | -0.187733 | -0.167041 | 0.125000 | 0.263700 | 0.048100 | 0.981700 | 0.000500 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 2 | 0.200000 | 0.010000 | risky_ps_old | -0.241564 | risky_ps_old | 1 | -0.241564 | -0.067766 | direct_multistage_exp3 | -0.067766 | -0.154273 | -0.110945 | -0.325787 | -0.155457 | 0.065000 | 0.294100 | 0.082400 | 0.982200 | 0.109800 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 2 | 0.200000 | 0.005000 | risky_ps_old | -0.218325 | risky_ps_old | 1 | -0.218325 | -0.044528 | direct_multistage_exp3 | -0.044528 | -0.131034 | -0.093403 | -0.302549 | -0.140557 | 0.045000 | 0.256900 | 0.086100 | 0.981600 | 0.104300 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 2 | 0.200000 | 0.020000 | risky_ps_old | -0.212478 | risky_ps_old | 1 | -0.212478 | -0.033133 | epsilon_exp3 | -0.038681 | -0.125187 | -0.033133 | -0.296702 | -0.135357 | 0.065000 | 0.248100 | 0.077000 | 0.981100 | 0.141300 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 3 | 0.200000 | 0.020000 | risky_ps_old | -0.179921 | risky_ps_old | 1 | -0.179921 | -0.075200 | direct_multistage_exp3 | -0.075200 | -0.099200 | -0.132267 | -0.120133 | -0.109641 | 0.215000 | 0.292300 | 0.060800 | 0.976500 | 0.005800 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 3 | 0.200000 | 0.005000 | risky_ps_ix | -0.179121 | risky_ps_ix | 1 | -0.179121 | -0.074400 | direct_multistage_exp3 | -0.074400 | -0.098400 | -0.092000 | -0.119333 | -0.110841 | 0.175000 | 0.241400 | 0.077100 | 0.979900 | 0.000300 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 3 | 0.200000 | 0.010000 | risky_ps_old | -0.132988 | risky_ps_old | 1 | -0.132988 | -0.028267 | direct_multistage_exp3 | -0.028267 | -0.052267 | -0.072800 | -0.073200 | -0.075341 | 0.240000 | 0.176100 | 0.070400 | 0.977000 | 0.001900 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 4 | 0.400000 | 0.010000 | risky_ps_ix | -0.114977 | risky_ps_ix | 1 | -0.114977 | -0.022500 | epsilon_exp3 | -0.033500 | -0.056375 | -0.022500 | -0.111250 | -0.084614 | 0.145000 | 0.169900 | 0.048900 | 0.976000 | 0.063600 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 4 | 0.400000 | 0.005000 | risky_ps | -0.112477 | risky_ps | 1 | -0.112477 | -0.024375 | epsilon_exp3 | -0.031000 | -0.053875 | -0.024375 | -0.108750 | -0.082914 | 0.040000 | 0.186100 | 0.039500 | 0.976600 | 0.057200 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 4 | 0.200000 | 0.010000 | risky_ps_old | -0.070852 | risky_ps_old | 1 | -0.070852 | -0.067125 | naive_mixed_avg | -0.103250 | -0.079625 | -0.080375 | -0.067125 | -0.042914 | 0.105000 | 0.265500 | 0.059100 | 0.977500 | 0.100900 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 6 | 0.300000 | 0.010000 | risky_ps | -0.066378 | risky_ps | 1 | -0.066378 | -0.006294 | naive_mixed_avg | -0.011772 | -0.085198 | -0.018182 | -0.006294 | -0.044893 | 0.105000 | 0.217800 | 0.040700 | 0.975200 | 0.103200 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 4 | 0.200000 | 0.005000 | risky_ps | -0.037977 | risky_ps | 1 | -0.037977 | -0.034250 | naive_mixed_avg | -0.070375 | -0.046750 | -0.050625 | -0.034250 | -0.017814 | 0.080000 | 0.228300 | 0.065200 | 0.973900 | 0.069000 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 1 | 0.400000 | 0.005000 | risky_ps_old | 0.130000 | risky_ps_old | 1 | 0.130000 | -0.027400 | direct_multistage_exp3 | -0.027400 | -0.110600 | -0.082000 | -0.178400 | 0.057468 | 0.065000 | 0.260600 | 0.081100 | 0.983100 | 0.166500 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 1 | 0.200000 | 0.005000 | risky_ps_old | 0.149200 | risky_ps_old | 1 | 0.149200 | -0.061400 | direct_multistage_exp3 | -0.061400 | -0.164200 | -0.152600 | -0.159200 | 0.073568 | 0.030000 | 0.246600 | 0.110300 | 0.982400 | 0.140900 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 1 | 0.200000 | 0.010000 | risky_ps_old | 0.153000 | risky_ps_old | 1 | 0.153000 | -0.057600 | direct_multistage_exp3 | -0.057600 | -0.160400 | -0.132000 | -0.155400 | 0.076868 | 0.035000 | 0.286400 | 0.104400 | 0.981900 | 0.118500 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 1 | 0.400000 | 0.010000 | risky_ps_old | 0.156000 | risky_ps_old | 1 | 0.156000 | -0.001400 | direct_multistage_exp3 | -0.001400 | -0.084600 | -0.065600 | -0.152400 | 0.071068 | 0.070000 | 0.255300 | 0.099700 | 0.981000 | 0.186300 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 1 | 0.200000 | 0.020000 | risky_ps_old | 0.159000 | risky_ps_old | 1 | 0.159000 | -0.051600 | direct_multistage_exp3 | -0.051600 | -0.154400 | -0.150000 | -0.149400 | 0.081868 | 0.050000 | 0.310800 | 0.096400 | 0.981400 | 0.101500 |

### Top configs across all methods

| experiment_name | control_kind | control_value | eta | epsilon | best_post_method | best_post_value | best_ps_method | best_ps_post_rank | best_ps_post_value | ps_minus_best_nonps_post | best_nonps_method | ps_minus_direct_multistage_exp3_post | ps_minus_direct_multistage_exp3_local_post | ps_minus_epsilon_exp3_post | ps_minus_naive_mixed_avg_post | best_ps_regret_per_t | best_ps_tail20 | best_ps_target_good_fraction | best_ps_trap_basin_fraction | best_ps_shared_path_fraction | best_ps_exact_hit |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 2 | 0.400000 | 0.020000 | direct_multistage_exp3 | -0.259105 | risky_ps_old | 2 | -0.251609 | 0.007496 | direct_multistage_exp3 | 0.007496 | -0.085157 | -0.060420 | -0.335832 | -0.168257 | 0.095000 | 0.296300 | 0.070400 | 0.983200 | 0.051400 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 2 | 0.400000 | 0.005000 | direct_multistage_exp3 | -0.259105 | risky_ps_old | 2 | -0.250259 | 0.008846 | direct_multistage_exp3 | 0.008846 | -0.083808 | -0.029085 | -0.334483 | -0.168557 | 0.055000 | 0.199700 | 0.059200 | 0.983700 | 0.036600 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 2 | 0.400000 | 0.010000 | direct_multistage_exp3 | -0.259105 | risky_ps_old | 2 | -0.215327 | 0.043778 | direct_multistage_exp3 | 0.043778 | -0.048876 | -0.041229 | -0.299550 | -0.144657 | 0.100000 | 0.217500 | 0.068500 | 0.980900 | 0.057700 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 2 | 0.300000 | 0.005000 | epsilon_exp3 | -0.256106 | risky_ps_old | 4 | -0.196736 | 0.059370 | epsilon_exp3 | 0.026237 | 0.013193 | 0.059370 | -0.280960 | -0.131257 | 0.105000 | 0.287500 | 0.058900 | 0.983000 | 0.075000 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 3 | 0.400000 | 0.020000 | risky_ps_old | -0.247521 | risky_ps_old | 1 | -0.247521 | -0.011200 | direct_multistage_exp3 | -0.011200 | -0.044533 | -0.039200 | -0.187733 | -0.167041 | 0.125000 | 0.263700 | 0.048100 | 0.981700 | 0.000500 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 2 | 0.300000 | 0.010000 | epsilon_exp3 | -0.247111 | risky_ps_old | 2 | -0.223273 | 0.023838 | epsilon_exp3 | -0.000300 | -0.013343 | 0.023838 | -0.307496 | -0.148157 | 0.055000 | 0.221200 | 0.056500 | 0.982400 | 0.064600 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 2 | 0.200000 | 0.010000 | risky_ps_old | -0.241564 | risky_ps_old | 1 | -0.241564 | -0.067766 | direct_multistage_exp3 | -0.067766 | -0.154273 | -0.110945 | -0.325787 | -0.155457 | 0.065000 | 0.294100 | 0.082400 | 0.982200 | 0.109800 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 3 | 0.400000 | 0.005000 | direct_multistage_exp3 | -0.236321 | risky_ps_old | 2 | -0.227255 | 0.009067 | direct_multistage_exp3 | 0.009067 | -0.024267 | -0.060933 | -0.167467 | -0.152941 | 0.175000 | 0.216600 | 0.043000 | 0.981900 | 0.001900 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 3 | 0.400000 | 0.010000 | direct_multistage_exp3 | -0.236321 | risky_ps_old | 2 | -0.222321 | 0.014000 | direct_multistage_exp3 | 0.014000 | -0.019333 | -0.056400 | -0.162533 | -0.148641 | 0.100000 | 0.231500 | 0.053300 | 0.979400 | 0.000800 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 2 | 0.300000 | 0.020000 | direct_multistage_exp3 | -0.222973 | risky_ps_old | 2 | -0.222073 | 0.000900 | direct_multistage_exp3 | 0.000900 | -0.012144 | -0.075262 | -0.306297 | -0.148557 | 0.035000 | 0.281500 | 0.053600 | 0.983500 | 0.048900 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 2 | 0.200000 | 0.005000 | risky_ps_old | -0.218325 | risky_ps_old | 1 | -0.218325 | -0.044528 | direct_multistage_exp3 | -0.044528 | -0.131034 | -0.093403 | -0.302549 | -0.140557 | 0.045000 | 0.256900 | 0.086100 | 0.981600 | 0.104300 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 3 | 0.300000 | 0.010000 | epsilon_exp3 | -0.212588 | risky_ps_old | 3 | -0.144855 | 0.067733 | epsilon_exp3 | 0.064400 | -0.020133 | 0.067733 | -0.085067 | -0.088341 | 0.230000 | 0.190800 | 0.052300 | 0.975200 | 0.000900 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 2 | 0.200000 | 0.020000 | risky_ps_old | -0.212478 | risky_ps_old | 1 | -0.212478 | -0.033133 | epsilon_exp3 | -0.038681 | -0.125187 | -0.033133 | -0.296702 | -0.135357 | 0.065000 | 0.248100 | 0.077000 | 0.981100 | 0.141300 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 3 | 0.300000 | 0.020000 | direct_multistage_exp3 | -0.209255 | risky_ps_old | 2 | -0.197388 | 0.011867 | direct_multistage_exp3 | 0.011867 | -0.072667 | -0.065467 | -0.137600 | -0.128441 | 0.055000 | 0.224800 | 0.049500 | 0.978800 | 0.001700 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 3 | 0.300000 | 0.005000 | direct_multistage_exp3 | -0.209255 | risky_ps | 2 | -0.194455 | 0.014800 | direct_multistage_exp3 | 0.014800 | -0.069733 | -0.056800 | -0.134667 | -0.125941 | 0.050000 | 0.243200 | 0.055200 | 0.978800 | 0.000200 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 3 | 0.200000 | 0.020000 | risky_ps_old | -0.179921 | risky_ps_old | 1 | -0.179921 | -0.075200 | direct_multistage_exp3 | -0.075200 | -0.099200 | -0.132267 | -0.120133 | -0.109641 | 0.215000 | 0.292300 | 0.060800 | 0.976500 | 0.005800 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 3 | 0.200000 | 0.005000 | risky_ps_ix | -0.179121 | risky_ps_ix | 1 | -0.179121 | -0.074400 | direct_multistage_exp3 | -0.074400 | -0.098400 | -0.092000 | -0.119333 | -0.110841 | 0.175000 | 0.241400 | 0.077100 | 0.979900 | 0.000300 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 3 | 0.200000 | 0.010000 | risky_ps_old | -0.132988 | risky_ps_old | 1 | -0.132988 | -0.028267 | direct_multistage_exp3 | -0.028267 | -0.052267 | -0.072800 | -0.073200 | -0.075341 | 0.240000 | 0.176100 | 0.070400 | 0.977000 | 0.001900 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 6 | 0.400000 | 0.010000 | direct_multistage_exp3 | -0.120807 | risky_ps_ix | 3 | -0.084444 | 0.036364 | direct_multistage_exp3 | 0.036364 | -0.017249 | 0.014103 | -0.024359 | -0.062293 | 0.100000 | 0.223800 | 0.037600 | 0.979400 | 0.085400 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 6 | 0.400000 | 0.005000 | direct_multistage_exp3 | -0.120807 | risky_ps_old | 3 | -0.077800 | 0.043007 | direct_multistage_exp3 | 0.043007 | -0.010606 | 0.005711 | -0.017716 | -0.056793 | 0.185000 | 0.242800 | 0.035800 | 0.974400 | 0.130200 |

### Best by method, post-switch

| best_post_rank | method | control_value | eta_sweep | epsilon_sweep | post_switch_avg_regret_mean | tail20_avg_total_cost_mean | regret_per_t_mean | target_good_fraction_mean | trap_basin_fraction_mean | shared_path_fraction_mean | exact_best_path_hit_rate_mean |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | direct_multistage_exp3 | 2 | 0.400000 | 0.005000 | -0.259105 | 0.040000 | -0.174157 | 0.281200 | 0.106000 | 0.978900 | 0.140600 |
| 2 | epsilon_exp3 | 2 | 0.300000 | 0.005000 | -0.256106 | 0.050000 | -0.170257 | 0.238500 | 0.076600 | 0.982900 | 0.068100 |
| 3 | risky_ps_old | 2 | 0.400000 | 0.020000 | -0.251609 | 0.095000 | -0.168257 | 0.296300 | 0.070400 | 0.983200 | 0.051400 |
| 4 | risky_ps_linear | 2 | 0.400000 | 0.005000 | -0.233618 | 0.105000 | -0.157557 | 0.216700 | 0.049300 | 0.983100 | 0.082900 |
| 5 | direct_multistage_exp3_local | 2 | 0.300000 | 0.005000 | -0.209929 | 0.045000 | -0.132357 | 0.241700 | 0.068800 | 0.980200 | 0.063300 |
| 6 | risky_ps | 2 | 0.400000 | 0.005000 | -0.207081 | 0.030000 | -0.140057 | 0.251200 | 0.051500 | 0.983000 | 0.073700 |
| 7 | risky_ps_ix | 2 | 0.400000 | 0.005000 | -0.205432 | 0.030000 | -0.138957 | 0.250900 | 0.051800 | 0.983100 | 0.076800 |
| 8 | risky_ps_safe_conditional_ix | 3 | 0.400000 | 0.005000 | -0.204055 | 0.120000 | -0.135441 | 0.179600 | 0.046100 | 0.979200 | 0.001000 |
| 9 | risky_ps_safe_conditional | 3 | 0.400000 | 0.005000 | -0.192588 | 0.175000 | -0.126841 | 0.166500 | 0.049700 | 0.978200 | 0.000900 |
| 10 | risky_ps_direct_cost | 2 | 0.400000 | 0.005000 | -0.157456 | 0.160000 | -0.106957 | 0.056000 | 0.049500 | 0.981400 | 0.016800 |
| 11 | naive_mixed_avg | 5 | 0.200000 | 0.005000 | -0.067901 | 0.000000 | -0.067198 | 0.556100 | 0.000000 | 1.000000 | 0.237700 |
| 12 | naive_mixed | 3 | 0.200000 | 0.005000 | 0.060745 | 0.030000 | 0.043059 | 0.281900 | 0.000000 | 1.000000 | 0.000000 |
| 13 | random_path | 3 | 0.200000 | 0.005000 | 0.253279 | 0.755000 | 0.284659 | 0.035100 | 0.079200 | 0.929300 | 0.002100 |

## sim_v12_gapcompressed_d4_7_top3_etaeps_full13_v1

v12 compression ablation: d=4,5,6,7，检验是否只是 n=7/eta=0.2/eps=0.01 参数不佳。

- cost_mode: `ps_favored_trap_v12_gap_compressed_baited`
- control_kind: `d`
- control_values: `[4, 5, 6, 7]`
- combos: `36`
- PS-winning combos: `0` / `36`

### Top PS-winning configs

| empty |
| --- |
| no rows |

### Top configs across all methods

| experiment_name | control_kind | control_value | eta | epsilon | best_post_method | best_post_value | best_ps_method | best_ps_post_rank | best_ps_post_value | ps_minus_best_nonps_post | best_nonps_method | ps_minus_direct_multistage_exp3_post | ps_minus_direct_multistage_exp3_local_post | ps_minus_epsilon_exp3_post | ps_minus_naive_mixed_avg_post | best_ps_regret_per_t | best_ps_tail20 | best_ps_target_good_fraction | best_ps_trap_basin_fraction | best_ps_shared_path_fraction | best_ps_exact_hit |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| sim_v12_gapcompressed_d4_7_top3_etaeps_full13_v1 | d | 4 | 0.300000 | 0.005000 | naive_mixed_avg | 0.022032 | risky_ps_linear | 2 | 0.031499 | 0.009467 | naive_mixed_avg | -0.002933 | -0.005067 | -0.011200 | 0.009467 | 0.042824 | 0.025000 | 0.232800 | 0.032600 | 0.968000 | 0.003200 |
| sim_v12_gapcompressed_d4_7_top3_etaeps_full13_v1 | d | 4 | 0.400000 | 0.020000 | naive_mixed_avg | 0.022032 | risky_ps_old | 4 | 0.033365 | 0.011333 | naive_mixed_avg | 0.009467 | 0.001067 | -0.012667 | 0.011333 | 0.043824 | 0.035000 | 0.303100 | 0.034200 | 0.967000 | 0.002300 |
| sim_v12_gapcompressed_d4_7_top3_etaeps_full13_v1 | d | 4 | 0.200000 | 0.005000 | naive_mixed_avg | 0.022032 | risky_ps_old | 2 | 0.033899 | 0.011867 | naive_mixed_avg | -0.014400 | -0.014533 | -0.007867 | 0.011867 | 0.048624 | 0.035000 | 0.293200 | 0.061500 | 0.964800 | 0.002300 |
| sim_v12_gapcompressed_d4_7_top3_etaeps_full13_v1 | d | 4 | 0.400000 | 0.005000 | naive_mixed_avg | 0.022032 | risky_ps_old | 4 | 0.034299 | 0.012267 | naive_mixed_avg | 0.010400 | 0.002000 | -0.002400 | 0.012267 | 0.043024 | 0.025000 | 0.256200 | 0.036100 | 0.965400 | 0.000400 |
| sim_v12_gapcompressed_d4_7_top3_etaeps_full13_v1 | d | 4 | 0.400000 | 0.010000 | naive_mixed_avg | 0.022032 | risky_ps_old | 4 | 0.034565 | 0.012533 | naive_mixed_avg | 0.010667 | 0.002267 | -0.000133 | 0.012533 | 0.044224 | 0.035000 | 0.350100 | 0.034600 | 0.965100 | 0.000600 |
| sim_v12_gapcompressed_d4_7_top3_etaeps_full13_v1 | d | 4 | 0.300000 | 0.010000 | naive_mixed_avg | 0.022032 | risky_ps_old | 3 | 0.035365 | 0.013333 | naive_mixed_avg | 0.000933 | -0.001200 | -0.010800 | 0.013333 | 0.045924 | 0.010000 | 0.222700 | 0.032100 | 0.961000 | 0.000900 |
| sim_v12_gapcompressed_d4_7_top3_etaeps_full13_v1 | d | 4 | 0.200000 | 0.020000 | naive_mixed_avg | 0.022032 | risky_ps_old | 2 | 0.038165 | 0.016133 | naive_mixed_avg | -0.010133 | -0.010267 | -0.010667 | 0.016133 | 0.053324 | 0.030000 | 0.344200 | 0.058600 | 0.964900 | 0.001000 |
| sim_v12_gapcompressed_d4_7_top3_etaeps_full13_v1 | d | 4 | 0.200000 | 0.010000 | naive_mixed_avg | 0.022032 | risky_ps_old | 2 | 0.038565 | 0.016533 | naive_mixed_avg | -0.009733 | -0.009867 | -0.013333 | 0.016533 | 0.052324 | 0.040000 | 0.352300 | 0.064500 | 0.967800 | 0.001300 |
| sim_v12_gapcompressed_d4_7_top3_etaeps_full13_v1 | d | 4 | 0.300000 | 0.020000 | naive_mixed_avg | 0.022032 | risky_ps_linear | 4 | 0.039099 | 0.017067 | naive_mixed_avg | 0.004667 | 0.002533 | -0.009067 | 0.017067 | 0.050624 | 0.005000 | 0.197000 | 0.033600 | 0.954800 | 0.010700 |
| sim_v12_gapcompressed_d4_7_top3_etaeps_full13_v1 | d | 7 | 0.400000 | 0.020000 | naive_mixed_avg | 0.027413 | risky_ps_old | 3 | 0.037203 | 0.009790 | naive_mixed_avg | 0.002914 | -0.003263 | -0.005361 | 0.009790 | 0.041780 | 0.025000 | 0.454700 | 0.020600 | 0.978900 | 0.196900 |
| sim_v12_gapcompressed_d4_7_top3_etaeps_full13_v1 | d | 7 | 0.400000 | 0.005000 | naive_mixed_avg | 0.027413 | risky_ps_old | 3 | 0.038019 | 0.010606 | naive_mixed_avg | 0.003730 | -0.002448 | -0.003846 | 0.010606 | 0.042080 | 0.025000 | 0.309900 | 0.024700 | 0.964400 | 0.167200 |
| sim_v12_gapcompressed_d4_7_top3_etaeps_full13_v1 | d | 7 | 0.300000 | 0.010000 | naive_mixed_avg | 0.027413 | risky_ps_direct_cost | 2 | 0.039417 | 0.012005 | naive_mixed_avg | -0.003846 | -0.004079 | -0.005012 | 0.012005 | 0.044980 | 0.030000 | 0.142400 | 0.021300 | 0.959900 | 0.032500 |
| sim_v12_gapcompressed_d4_7_top3_etaeps_full13_v1 | d | 7 | 0.400000 | 0.010000 | naive_mixed_avg | 0.027413 | risky_ps_old | 4 | 0.039767 | 0.012354 | naive_mixed_avg | 0.005478 | -0.000699 | 0.000117 | 0.012354 | 0.043880 | 0.030000 | 0.332500 | 0.023500 | 0.956800 | 0.166800 |
| sim_v12_gapcompressed_d4_7_top3_etaeps_full13_v1 | d | 7 | 0.300000 | 0.005000 | naive_mixed_avg | 0.027413 | risky_ps | 2 | 0.040583 | 0.013170 | naive_mixed_avg | -0.002681 | -0.002914 | -0.002331 | 0.013170 | 0.045480 | 0.035000 | 0.154600 | 0.024300 | 0.959300 | 0.052700 |
| sim_v12_gapcompressed_d4_7_top3_etaeps_full13_v1 | d | 7 | 0.200000 | 0.005000 | naive_mixed_avg | 0.027413 | risky_ps_old | 2 | 0.041399 | 0.013986 | naive_mixed_avg | -0.008159 | -0.007226 | -0.011189 | 0.013986 | 0.049180 | 0.035000 | 0.283400 | 0.033000 | 0.967300 | 0.131100 |
| sim_v12_gapcompressed_d4_7_top3_etaeps_full13_v1 | d | 7 | 0.300000 | 0.020000 | naive_mixed_avg | 0.027413 | risky_ps_linear | 2 | 0.042214 | 0.014802 | naive_mixed_avg | -0.001049 | -0.001282 | -0.004662 | 0.014802 | 0.048480 | 0.025000 | 0.230000 | 0.024100 | 0.952000 | 0.127500 |
| sim_v12_gapcompressed_d4_7_top3_etaeps_full13_v1 | d | 7 | 0.200000 | 0.010000 | naive_mixed_avg | 0.027413 | risky_ps_old | 2 | 0.043030 | 0.015618 | naive_mixed_avg | -0.006527 | -0.005594 | -0.011422 | 0.015618 | 0.050480 | 0.080000 | 0.320100 | 0.033600 | 0.971600 | 0.155700 |
| sim_v12_gapcompressed_d4_7_top3_etaeps_full13_v1 | d | 7 | 0.200000 | 0.020000 | naive_mixed_avg | 0.027413 | risky_ps_linear | 2 | 0.043963 | 0.016550 | naive_mixed_avg | -0.005594 | -0.004662 | -0.007925 | 0.016550 | 0.052380 | 0.025000 | 0.346200 | 0.032100 | 0.966800 | 0.174600 |
| sim_v12_gapcompressed_d4_7_top3_etaeps_full13_v1 | d | 6 | 0.400000 | 0.020000 | naive_mixed_avg | 0.029568 | risky_ps_old | 3 | 0.037602 | 0.008034 | naive_mixed_avg | 0.002758 | -0.007794 | -0.010671 | 0.008034 | 0.040392 | 0.020000 | 0.350900 | 0.024000 | 0.959700 | 0.152500 |
| sim_v12_gapcompressed_d4_7_top3_etaeps_full13_v1 | d | 6 | 0.400000 | 0.010000 | naive_mixed_avg | 0.029568 | risky_ps_linear | 3 | 0.040240 | 0.010671 | naive_mixed_avg | 0.005396 | -0.005156 | -0.003118 | 0.010671 | 0.042792 | 0.025000 | 0.333000 | 0.025400 | 0.965300 | 0.131000 |

### Best by method, post-switch

| best_post_rank | method | control_value | eta_sweep | epsilon_sweep | post_switch_avg_regret_mean | tail20_avg_total_cost_mean | regret_per_t_mean | target_good_fraction_mean | trap_basin_fraction_mean | shared_path_fraction_mean | exact_best_path_hit_rate_mean |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | naive_mixed_avg | 4 | 0.200000 | 0.005000 | 0.022032 | 0.020000 | 0.014524 | 0.174200 | 0.000000 | 0.998700 | 0.000000 |
| 2 | direct_multistage_exp3 | 4 | 0.400000 | 0.005000 | 0.023899 | 0.030000 | 0.035624 | 0.276200 | 0.064600 | 0.959500 | 0.005000 |
| 3 | risky_ps_linear | 4 | 0.300000 | 0.005000 | 0.031499 | 0.025000 | 0.042824 | 0.232800 | 0.032600 | 0.968000 | 0.003200 |
| 4 | direct_multistage_exp3_local | 4 | 0.400000 | 0.005000 | 0.032299 | 0.035000 | 0.045724 | 0.165500 | 0.072300 | 0.948300 | 0.004400 |
| 5 | risky_ps_old | 4 | 0.300000 | 0.005000 | 0.032565 | 0.020000 | 0.043924 | 0.241000 | 0.032800 | 0.965900 | 0.001200 |
| 6 | epsilon_exp3 | 4 | 0.400000 | 0.010000 | 0.034699 | 0.045000 | 0.045324 | 0.229800 | 0.094100 | 0.948500 | 0.000700 |
| 7 | risky_ps | 4 | 0.400000 | 0.005000 | 0.034832 | 0.035000 | 0.043424 | 0.205700 | 0.036400 | 0.960400 | 0.001200 |
| 8 | risky_ps_direct_cost | 4 | 0.400000 | 0.010000 | 0.035365 | 0.035000 | 0.044824 | 0.151300 | 0.034700 | 0.958400 | 0.004400 |
| 9 | risky_ps_ix | 4 | 0.400000 | 0.005000 | 0.035499 | 0.030000 | 0.043924 | 0.210100 | 0.036400 | 0.962000 | 0.001000 |
| 10 | risky_ps_safe_conditional | 4 | 0.400000 | 0.010000 | 0.038699 | 0.045000 | 0.047324 | 0.161700 | 0.035100 | 0.957600 | 0.004200 |
| 11 | risky_ps_safe_conditional_ix | 4 | 0.400000 | 0.010000 | 0.038699 | 0.045000 | 0.047324 | 0.161700 | 0.035100 | 0.957600 | 0.004200 |
| 12 | random_path | 4 | 0.200000 | 0.005000 | 0.185632 | 0.215000 | 0.229624 | 0.072000 | 0.079200 | 0.929300 | 0.001900 |
| 13 | naive_mixed | 4 | 0.200000 | 0.005000 | 0.686032 | 0.890000 | 0.512524 | 0.088300 | 0.000000 | 1.000000 | 0.000000 |

## Global Top PS-winning configs

| experiment_name | control_kind | control_value | eta | epsilon | best_post_method | best_post_value | best_ps_method | best_ps_post_rank | best_ps_post_value | ps_minus_best_nonps_post | best_nonps_method | ps_minus_direct_multistage_exp3_post | ps_minus_direct_multistage_exp3_local_post | ps_minus_epsilon_exp3_post | ps_minus_naive_mixed_avg_post | best_ps_regret_per_t | best_ps_tail20 | best_ps_target_good_fraction | best_ps_trap_basin_fraction | best_ps_shared_path_fraction | best_ps_exact_hit |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 3 | 0.400000 | 0.020000 | risky_ps_old | -0.247521 | risky_ps_old | 1 | -0.247521 | -0.011200 | direct_multistage_exp3 | -0.011200 | -0.044533 | -0.039200 | -0.187733 | -0.167041 | 0.125000 | 0.263700 | 0.048100 | 0.981700 | 0.000500 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 2 | 0.200000 | 0.010000 | risky_ps_old | -0.241564 | risky_ps_old | 1 | -0.241564 | -0.067766 | direct_multistage_exp3 | -0.067766 | -0.154273 | -0.110945 | -0.325787 | -0.155457 | 0.065000 | 0.294100 | 0.082400 | 0.982200 | 0.109800 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 2 | 0.200000 | 0.005000 | risky_ps_old | -0.218325 | risky_ps_old | 1 | -0.218325 | -0.044528 | direct_multistage_exp3 | -0.044528 | -0.131034 | -0.093403 | -0.302549 | -0.140557 | 0.045000 | 0.256900 | 0.086100 | 0.981600 | 0.104300 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 2 | 0.200000 | 0.020000 | risky_ps_old | -0.212478 | risky_ps_old | 1 | -0.212478 | -0.033133 | epsilon_exp3 | -0.038681 | -0.125187 | -0.033133 | -0.296702 | -0.135357 | 0.065000 | 0.248100 | 0.077000 | 0.981100 | 0.141300 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 3 | 0.200000 | 0.020000 | risky_ps_old | -0.179921 | risky_ps_old | 1 | -0.179921 | -0.075200 | direct_multistage_exp3 | -0.075200 | -0.099200 | -0.132267 | -0.120133 | -0.109641 | 0.215000 | 0.292300 | 0.060800 | 0.976500 | 0.005800 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 3 | 0.200000 | 0.005000 | risky_ps_ix | -0.179121 | risky_ps_ix | 1 | -0.179121 | -0.074400 | direct_multistage_exp3 | -0.074400 | -0.098400 | -0.092000 | -0.119333 | -0.110841 | 0.175000 | 0.241400 | 0.077100 | 0.979900 | 0.000300 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 3 | 0.200000 | 0.010000 | risky_ps_old | -0.132988 | risky_ps_old | 1 | -0.132988 | -0.028267 | direct_multistage_exp3 | -0.028267 | -0.052267 | -0.072800 | -0.073200 | -0.075341 | 0.240000 | 0.176100 | 0.070400 | 0.977000 | 0.001900 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 4 | 0.400000 | 0.010000 | risky_ps_ix | -0.114977 | risky_ps_ix | 1 | -0.114977 | -0.022500 | epsilon_exp3 | -0.033500 | -0.056375 | -0.022500 | -0.111250 | -0.084614 | 0.145000 | 0.169900 | 0.048900 | 0.976000 | 0.063600 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 4 | 0.400000 | 0.005000 | risky_ps | -0.112477 | risky_ps | 1 | -0.112477 | -0.024375 | epsilon_exp3 | -0.031000 | -0.053875 | -0.024375 | -0.108750 | -0.082914 | 0.040000 | 0.186100 | 0.039500 | 0.976600 | 0.057200 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 4 | 0.200000 | 0.010000 | risky_ps_old | -0.070852 | risky_ps_old | 1 | -0.070852 | -0.067125 | naive_mixed_avg | -0.103250 | -0.079625 | -0.080375 | -0.067125 | -0.042914 | 0.105000 | 0.265500 | 0.059100 | 0.977500 | 0.100900 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 6 | 0.300000 | 0.010000 | risky_ps | -0.066378 | risky_ps | 1 | -0.066378 | -0.006294 | naive_mixed_avg | -0.011772 | -0.085198 | -0.018182 | -0.006294 | -0.044893 | 0.105000 | 0.217800 | 0.040700 | 0.975200 | 0.103200 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 4 | 0.200000 | 0.005000 | risky_ps | -0.037977 | risky_ps | 1 | -0.037977 | -0.034250 | naive_mixed_avg | -0.070375 | -0.046750 | -0.050625 | -0.034250 | -0.017814 | 0.080000 | 0.228300 | 0.065200 | 0.973900 | 0.069000 |
| sim_v10_d2_4_top3_etaeps_full13_v1 | d | 4 | 0.300000 | 0.010000 | risky_ps_old | 0.078400 | risky_ps_old | 1 | 0.078400 | -0.019467 | direct_multistage_exp3 | -0.019467 | -0.036667 | -0.026133 | -0.056933 | 0.066184 | 0.015000 | 0.728600 | 0.045600 | 0.989300 | 0.378400 |
| sim_v10_d2_4_top3_etaeps_full13_v1 | d | 4 | 0.300000 | 0.020000 | risky_ps_old | 0.086533 | risky_ps_old | 1 | 0.086533 | -0.011333 | direct_multistage_exp3 | -0.011333 | -0.028533 | -0.021600 | -0.048800 | 0.073284 | 0.030000 | 0.713200 | 0.054300 | 0.986000 | 0.350900 |
| sim_v10_d2_4_top3_etaeps_full13_v1 | d | 3 | 0.400000 | 0.005000 | risky_ps_old | 0.098246 | risky_ps_old | 1 | 0.098246 | -0.034183 | direct_multistage_exp3_local | -0.080510 | -0.034183 | -0.069865 | -0.067616 | 0.066330 | 0.045000 | 0.655700 | 0.066000 | 0.986100 | 0.380600 |
| sim_v10_d2_4_top3_etaeps_full13_v1 | d | 4 | 0.400000 | 0.005000 | risky_ps_old | 0.099467 | risky_ps_old | 1 | 0.099467 | -0.009467 | direct_multistage_exp3 | -0.009467 | -0.020667 | -0.016400 | -0.035867 | 0.079584 | 0.030000 | 0.704900 | 0.056300 | 0.986600 | 0.276800 |
| sim_v10_d2_4_top3_etaeps_full13_v1 | d | 3 | 0.400000 | 0.010000 | risky_ps_old | 0.107391 | risky_ps_old | 1 | 0.107391 | -0.016942 | epsilon_exp3 | -0.071364 | -0.025037 | -0.016942 | -0.058471 | 0.072630 | 0.015000 | 0.647700 | 0.061600 | 0.986200 | 0.262600 |
| sim_v10_d2_4_top3_etaeps_full13_v1 | d | 3 | 0.300000 | 0.010000 | risky_ps_old | 0.108741 | risky_ps_old | 1 | 0.108741 | -0.014993 | direct_multistage_exp3 | -0.014993 | -0.059670 | -0.044828 | -0.057121 | 0.075430 | 0.025000 | 0.645500 | 0.062700 | 0.985900 | 0.365400 |
| sim_v10_d2_4_top3_etaeps_full13_v1 | d | 3 | 0.300000 | 0.020000 | risky_ps_old | 0.113238 | risky_ps_old | 1 | 0.113238 | -0.010495 | direct_multistage_exp3 | -0.010495 | -0.055172 | -0.047676 | -0.052624 | 0.081130 | 0.035000 | 0.636200 | 0.063400 | 0.985300 | 0.246100 |
| sim_v10_d2_4_top3_etaeps_full13_v1 | d | 2 | 0.400000 | 0.010000 | risky_ps_old | 0.126600 | risky_ps_old | 1 | 0.126600 | -0.040000 | direct_multistage_exp3_local | -0.100000 | -0.040000 | -0.071000 | -0.173800 | 0.054668 | 0.030000 | 0.527000 | 0.067300 | 0.986500 | 0.206200 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 1 | 0.400000 | 0.005000 | risky_ps_old | 0.130000 | risky_ps_old | 1 | 0.130000 | -0.027400 | direct_multistage_exp3 | -0.027400 | -0.110600 | -0.082000 | -0.178400 | 0.057468 | 0.065000 | 0.260600 | 0.081100 | 0.983100 | 0.166500 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 1 | 0.200000 | 0.005000 | risky_ps_old | 0.149200 | risky_ps_old | 1 | 0.149200 | -0.061400 | direct_multistage_exp3 | -0.061400 | -0.164200 | -0.152600 | -0.159200 | 0.073568 | 0.030000 | 0.246600 | 0.110300 | 0.982400 | 0.140900 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 1 | 0.200000 | 0.010000 | risky_ps_old | 0.153000 | risky_ps_old | 1 | 0.153000 | -0.057600 | direct_multistage_exp3 | -0.057600 | -0.160400 | -0.132000 | -0.155400 | 0.076868 | 0.035000 | 0.286400 | 0.104400 | 0.981900 | 0.118500 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 1 | 0.400000 | 0.010000 | risky_ps_old | 0.156000 | risky_ps_old | 1 | 0.156000 | -0.001400 | direct_multistage_exp3 | -0.001400 | -0.084600 | -0.065600 | -0.152400 | 0.071068 | 0.070000 | 0.255300 | 0.099700 | 0.981000 | 0.186300 |
| sim_v10_d2_4_top3_etaeps_full13_v1 | d | 2 | 0.400000 | 0.005000 | risky_ps_old | 0.157000 | risky_ps_old | 1 | 0.157000 | -0.009600 | direct_multistage_exp3_local | -0.069600 | -0.009600 | -0.071000 | -0.143400 | 0.071068 | 0.105000 | 0.503700 | 0.075800 | 0.982800 | 0.194600 |
| sim_v10_d2_4_top3_etaeps_full13_v1 | d | 2 | 0.300000 | 0.010000 | risky_ps_old | 0.157600 | risky_ps_old | 1 | 0.157600 | -0.040200 | direct_multistage_exp3_local | -0.076200 | -0.040200 | -0.085600 | -0.142800 | 0.072768 | 0.020000 | 0.510000 | 0.080800 | 0.984600 | 0.236400 |
| sim_v11_cyclic_switch1_6_top3_etaeps_full13_v1 | switch_count | 1 | 0.200000 | 0.020000 | risky_ps_old | 0.159000 | risky_ps_old | 1 | 0.159000 | -0.051600 | direct_multistage_exp3 | -0.051600 | -0.154400 | -0.150000 | -0.149400 | 0.081868 | 0.050000 | 0.310800 | 0.096400 | 0.981400 | 0.101500 |
| sim_v10_d2_4_top3_etaeps_full13_v1 | d | 2 | 0.300000 | 0.020000 | risky_ps_old | 0.161200 | risky_ps_old | 1 | 0.161200 | -0.036600 | direct_multistage_exp3_local | -0.072600 | -0.036600 | -0.093400 | -0.139200 | 0.077868 | 0.050000 | 0.503700 | 0.087900 | 0.983100 | 0.182200 |
| sim_v10_d2_4_top3_etaeps_full13_v1 | d | 2 | 0.300000 | 0.005000 | risky_ps_old | 0.192400 | risky_ps_old | 1 | 0.192400 | -0.005400 | direct_multistage_exp3_local | -0.041400 | -0.005400 | -0.027400 | -0.108000 | 0.090568 | 0.020000 | 0.474300 | 0.081300 | 0.983200 | 0.137700 |

## Files

- `all_layers_long.csv/json`
- `all_layers_combo_summaries.csv/json`
- `top_ps_winning_configs.csv`
- per-layer `combo_summaries.csv`, `best_by_method_post_switch.csv`, `best_by_method_overall.csv`
