| method | regret_per_t_mean | average_cost_mean | shared_path_fraction_mean | num_paths | horizon | seeds |
| --- | --- | --- | --- | --- | --- | --- |
| naive_mixed_avg | 0.11776230769234441 | 0.65 | 0.975 | 250 | 40 | 1 |
| risky_ps_old | 0.11776230769234441 | 0.65 | 0.7 | 250 | 40 | 1 |
| epsilon_exp3 | 0.1427623076923444 | 0.675 | 0.825 | 250 | 40 | 1 |
| random_path | 0.21776230769234442 | 0.75 | 0.65 | 250 | 40 | 1 |
| direct_multistage_exp3 | 0.2927623076923444 | 0.825 | 0.675 | 250 | 40 | 1 |
