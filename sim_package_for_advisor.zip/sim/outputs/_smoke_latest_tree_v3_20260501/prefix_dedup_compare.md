| method | regret_per_t_mean | terminal_proxy_mean | shared_path_fraction_mean | trap_basin_fraction_mean | target_subtree_fraction_mean | target_good_fraction_mean | target_bad_fraction_mean | calibrated_decoy_fraction_mean | decoy_branch_fraction_mean | ordinary_safe_basin_fraction_mean | broad_safe_basin_fraction_mean | ps_favored_exact_best_hit_rate_mean | num_paths | horizon | seeds |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| naive_mixed_avg | 0.11776230769234441 | 0.65 | 0.975 | 0.0 | 0.675 | 0.675 | 0.0 | 0.0 | 0.025 | 0.075 | 0.75 | 0.5 | 250 | 40 | 1 |
| risky_ps_old | 0.11776230769234441 | 0.65 | 0.7 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.05 | 0.0 | 0.0 | 0.0 | 250 | 40 | 1 |
| epsilon_exp3 | 0.1427623076923444 | 0.675 | 0.825 | 0.0 | 0.025 | 0.025 | 0.0 | 0.0 | 0.15 | 0.05 | 0.075 | 0.025 | 250 | 40 | 1 |
| random_path | 0.21776230769234442 | 0.75 | 0.65 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.125 | 0.05 | 0.05 | 0.0 | 250 | 40 | 1 |
| direct_multistage_exp3 | 0.2927623076923444 | 0.825 | 0.675 | 0.0 | 0.025 | 0.025 | 0.0 | 0.0 | 0.125 | 0.05 | 0.075 | 0.0 | 250 | 40 | 1 |
