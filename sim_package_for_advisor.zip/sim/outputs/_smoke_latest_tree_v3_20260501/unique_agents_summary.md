# Unique-agent 4/5-share controlled simulation

## Direct Answers
- The unique tree has num_paths=250 versus old partial_4of5 num_paths=3125.
- This is a real caveat: fewer paths make exploration easier, so any comparison mixes structure cleanup with a smaller path space. If risky_ps still does not close the gap under fewer paths, that weakens the cross-prefix-reuse hypothesis.

## Unique-Agent Tree Results
| method | regret_per_t_mean | average_cost_mean | shared_path_fraction_mean | num_paths | horizon | seeds |
| --- | --- | --- | --- | --- | --- | --- |
| naive_mixed_avg | 0.11776230769234441 | 0.65 | 0.975 | 250 | 40 | 1 |
| risky_ps_old | 0.11776230769234441 | 0.65 | 0.7 | 250 | 40 | 1 |
| epsilon_exp3 | 0.1427623076923444 | 0.675 | 0.825 | 250 | 40 | 1 |
| random_path | 0.21776230769234442 | 0.75 | 0.65 | 250 | 40 | 1 |
| direct_multistage_exp3 | 0.2927623076923444 | 0.825 | 0.675 | 250 | 40 | 1 |

## Old Tree Reference: main_partial_4of5_L5_K5
| method | regret_per_t_mean | terminal_proxy_mean | shared_path_fraction_mean | num_paths | horizon | seeds |
| --- | --- | --- | --- | --- | --- | --- |
| direct_multistage_exp3 | 0.0735857079360716 | 0.12053624211417821 | 0.98072 | 3125 | 5000 | 10 |
| risky_ps | 0.26536921693098714 | 0.31231975110909377 | 0.9079599999999999 | 3125 | 5000 | 10 |
| epsilon_exp3 | 0.26536921693098714 | 0.31231975110909377 | 0.9079599999999999 | 3125 | 5000 | 10 |
| naive_mixed | 0.34922459985788523 | 0.39617513403599186 | 0.02064 | 3125 | 5000 | 10 |
| random_path | 0.6295492983461468 | 0.6764998325242534 | 0.7983 | 3125 | 5000 | 10 |

## Delta vs Old Tree
| method | delta_regret_per_t | delta_terminal_proxy | delta_shared_path_fraction |
| --- | --- | --- | --- |
| epsilon_exp3 | -0.12260690923864273 | 0.3626802488909063 | -0.08295999999999992 |
| random_path | -0.4117869906538024 | 0.07350016747574661 | -0.1483 |
| direct_multistage_exp3 | 0.2191765997562728 | 0.7044637578858217 | -0.30572 |
