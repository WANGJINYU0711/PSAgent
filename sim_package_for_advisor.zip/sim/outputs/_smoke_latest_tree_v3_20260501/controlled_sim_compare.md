| setting | method_label | eta_shared | gamma_shared | num_paths | regret_per_t_mean | regret_per_t_std | average_cost_mean | exact_best_path_hit_rate_mean | shared_path_fraction_mean |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| shared_basin_strong_4of5_prefix_dedup_profile_switch_trap_asym_v3_efficient_anchor_4of5 | direct_multistage_exp3 | None | None | 250 | 0.2927623076923444 | 0.0 | 0.825 | 0.025 | 0.675 |
| shared_basin_strong_4of5_prefix_dedup_profile_switch_trap_asym_v3_efficient_anchor_4of5 | epsilon_exp3 | None | None | 250 | 0.1427623076923444 | 0.0 | 0.675 | 0.0 | 0.825 |
| shared_basin_strong_4of5_prefix_dedup_profile_switch_trap_asym_v3_efficient_anchor_4of5 | naive_mixed_avg | None | None | 250 | 0.11776230769234441 | 0.0 | 0.65 | 0.0 | 0.975 |
| shared_basin_strong_4of5_prefix_dedup_profile_switch_trap_asym_v3_efficient_anchor_4of5 | random_path | None | None | 250 | 0.21776230769234442 | 0.0 | 0.75 | 0.0 | 0.65 |
| shared_basin_strong_4of5_prefix_dedup_profile_switch_trap_asym_v3_efficient_anchor_4of5 | risky_ps_old | 0.3 | None | 250 | 0.11776230769234441 | 0.0 | 0.65 | 0.0 | 0.7 |
