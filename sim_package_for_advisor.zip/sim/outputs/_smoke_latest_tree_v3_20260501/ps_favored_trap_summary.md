# PS-favored trap controlled simulation

- tree_spec_cost_mode: `ps_favored_trap_v10_avg_baited`
- trap_basin_definition: `{'b1': 'stage1_n4', 'b2': ['stage2_n4', 'stage2_n5']}`
- trap_basin_leaf_count: `0`
- trap_path_base_aliases: `['stage1_n4', 'stage2_n5', 'stage3_n5', 'stage4_n5', 'stage5_n5']`
- exact_trap_path_exists: `False`
- trap_switch_denominator: `4`
- trap_switch_episode: `10`
- safe_basin_definition: `{'b3': ['stage3_n1', 'stage3_n2'], 'b4': 'stage4_n1', 'b5': ['stage5_n1', 'stage5_n2'], 'suffix_g': [0, 0, 0]}`
- cost_landscape_design: `v9_targeted_marginal_calibration`
- target_candidate_leaf_count: `4`
- target_good_leaf_count: `4`
- target_bad_leaf_count: `0`
- target_good_distribution_by_b3: `{'stage3_n1': 2, 'stage3_n2': 2}`
- target_good_distribution_by_b5: `{'stage5_n1': 2, 'stage5_n2': 2}`
- stage1_n3_stage2_n2_decoy_count: `0`
- stage1_n3_stage2_n3_decoy_count: `0`
- pre_calibration_stage1_n3_marginal: `{'stage2_n1': 0.7823516351491351, 'stage2_n2': 0.697839499299701, 'stage2_n3': None}`
- post_calibration_stage1_n3_marginal: `{'stage2_n1': 0.7823516351491351, 'stage2_n2': 0.697839499299701, 'stage2_n3': None}`
- calibration_actions: `{'g2_decoy_count': 0, 'g3_decoy_count': 0, 'g1_target_bad_adjusted': False, 'g1_target_bad_adjusted_p_range': None}`
- balancing_decoy_expected_p_range: `None`
- root_child_marginal_expected_cost: `{'stage1_n1': 0.6446394992422806, 'stage1_n2': 0.8257749504406773, 'stage1_n3': 0.7551003477924121, 'stage1_n4': 0.8315805033995676}`
- stage2_marginal_expected_cost: `{'stage1_n1': {'stage2_n1': 0.6838463742612375, 'stage2_n2': 0.6868825430308609, 'stage2_n4': 0.5797398072336473}, 'stage1_n2': {'stage2_n2': 0.825890160249199, 'stage2_n3': 0.7401224140997189, 'stage2_n4': 0.835481519016414}, 'stage1_n3': {'stage2_n1': 0.8066875794240036, 'stage2_n2': 0.7452186487995044, 'stage2_n4': 0.716467156199365}}`
- exact_best_path: `['stage1_n1__from__root__c01', 'stage2_n1__from__n0001__c01', 'stage3_n1__from__n0005__c01', 'stage4_n1__from__n0015__c01', 'stage5_n1__from__n0044__c01']`
- exact_best_base_aliases: `['stage1_n1', 'stage2_n1', 'stage3_n1', 'stage4_n1', 'stage5_n1']`
- exact_best_expected_probability: `0.6529544331872253`
- safe_basin_leaf_count: `17`
- safe_suffix_group_count: `4`
- oracle_best_leaf_type: `shared`
- oracle_best_is_shared: `True`
- target_ordering_met: `False`

## Method Results
| method | regret_per_t_mean | terminal_proxy_mean | shared_path_fraction_mean | trap_basin_fraction_mean | target_subtree_fraction_mean | target_good_fraction_mean | target_bad_fraction_mean | calibrated_decoy_fraction_mean | decoy_branch_fraction_mean | ordinary_safe_basin_fraction_mean | broad_safe_basin_fraction_mean | ps_favored_exact_best_hit_rate_mean | num_paths | horizon | seeds |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| naive_mixed_avg | 0.11776230769234441 | 0.65 | 0.975 | 0.0 | 0.675 | 0.675 | 0.0 | 0.0 | 0.025 | 0.075 | 0.75 | 0.5 | 250 | 40 | 1 |
| risky_ps_old | 0.11776230769234441 | 0.65 | 0.7 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.05 | 0.0 | 0.0 | 0.0 | 250 | 40 | 1 |
| epsilon_exp3 | 0.1427623076923444 | 0.675 | 0.825 | 0.0 | 0.025 | 0.025 | 0.0 | 0.0 | 0.15 | 0.05 | 0.075 | 0.025 | 250 | 40 | 1 |
| random_path | 0.21776230769234442 | 0.75 | 0.65 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.125 | 0.05 | 0.05 | 0.0 | 250 | 40 | 1 |
| direct_multistage_exp3 | 0.2927623076923444 | 0.825 | 0.675 | 0.0 | 0.025 | 0.025 | 0.0 | 0.0 | 0.125 | 0.05 | 0.075 | 0.0 | 250 | 40 | 1 |

## Ordering Checks
| risky_ps_better_than_epsilon_exp3 | epsilon_exp3_better_than_direct_multistage_exp3 | target_ordering_met |
| --- | --- | --- |
| False | True | False |

## Top-10 Leaf Expected Probabilities
| rank | mean_probability | leaf_type | family_label | base_aliases |
| --- | --- | --- | --- | --- |
| 1 | 0.5322376923076556 | shared | ps_favored_v10_non_safe_all_shared_post_switch | ['stage1_n1', 'stage2_n4', 'stage3_n1', 'stage4_n2', 'stage5_n2'] |
| 2 | 0.5362315923773655 | shared | ps_favored_v10_non_safe_all_shared_post_switch | ['stage1_n1', 'stage2_n4', 'stage3_n4', 'stage4_n2', 'stage5_n1'] |
| 3 | 0.5377346626736786 | shared | ps_favored_v10_non_safe_all_shared_post_switch | ['stage1_n1', 'stage2_n4', 'stage3_n4', 'stage4_n4', 'stage5_n4'] |
| 4 | 0.5453554954361288 | shared | ps_favored_v10_non_safe_all_shared_post_switch | ['stage1_n1', 'stage2_n4', 'stage3_n1', 'stage4_n1', 'stage5_n3'] |
| 5 | 0.5453589483421653 | shared | ps_favored_v10_non_safe_all_shared_post_switch | ['stage1_n1', 'stage2_n4', 'stage3_n2', 'stage4_n3', 'stage5_n4'] |
| 6 | 0.5461834365280512 | shared | ps_favored_v10_non_safe_all_shared_post_switch | ['stage1_n3', 'stage2_n4', 'stage3_n2', 'stage4_n2', 'stage5_n2'] |
| 7 | 0.5475031172471054 | shared | ps_favored_v10_non_safe_all_shared_post_switch | ['stage1_n1', 'stage2_n4', 'stage3_n2', 'stage4_n2', 'stage5_n2'] |
| 8 | 0.5497263261083216 | shared | ps_favored_v10_non_safe_all_shared_post_switch | ['stage1_n1', 'stage2_n4', 'stage3_n2', 'stage4_n2', 'stage5_n3'] |
| 9 | 0.549984360134845 | shared | ps_favored_v10_non_safe_all_shared_post_switch | ['stage1_n1', 'stage2_n4', 'stage3_n3', 'stage4_n2', 'stage5_n2'] |
| 10 | 0.5509086556496607 | shared | ps_favored_v10_non_safe_all_shared_post_switch | ['stage1_n1', 'stage2_n4', 'stage3_n4', 'stage4_n2', 'stage5_n2'] |

## Top Safe Suffix Signatures
| signature | leaf_count | mean_probability |
| --- | --- | --- |
| ['stage3_n1', 'stage4_n1', 'stage5_n2'] | 5 | 0.672347708567414 |
| ['stage3_n1', 'stage4_n1', 'stage5_n1'] | 5 | 0.6771413643522022 |
| ['stage3_n2', 'stage4_n1', 'stage5_n1'] | 4 | 0.6746264831905304 |
| ['stage3_n2', 'stage4_n1', 'stage5_n2'] | 3 | 0.7048252855829081 |
