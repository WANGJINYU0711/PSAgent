# Prefix-dedup controlled simulation

- tree_spec_role_mode: `spec_or_agent_id`
- depth: `5`
- num_paths: `250`
- total_agent_ids: `380`
- duplicate_agent_count: `None`
- cross_prefix_duplicate_count: `None`

## Current Tree
| method | regret_per_t_mean | terminal_proxy_mean | shared_path_fraction_mean | num_paths | horizon | seeds |
| --- | --- | --- | --- | --- | --- | --- |
| naive_mixed_avg | 0.11776230769234441 | 0.65 | 0.975 | 250 | 40 | 1 |
| risky_ps_old | 0.11776230769234441 | 0.65 | 0.7 | 250 | 40 | 1 |
| epsilon_exp3 | 0.1427623076923444 | 0.675 | 0.825 | 250 | 40 | 1 |
| random_path | 0.21776230769234442 | 0.75 | 0.65 | 250 | 40 | 1 |
| direct_multistage_exp3 | 0.2927623076923444 | 0.825 | 0.675 | 250 | 40 | 1 |

## Delta vs Old Theory-Aligned Partial 4/5 Reference
| method | delta_regret_per_t | delta_terminal_proxy | delta_shared_path_fraction |
| --- | --- | --- | --- |
| epsilon_exp3 | -0.12260690923864273 | 0.3626802488909063 | -0.08295999999999992 |
| random_path | -0.4117869906538024 | 0.07350016747574661 | -0.1483 |
| direct_multistage_exp3 | 0.2191765997562728 | 0.7044637578858217 | -0.30572 |

## Direct Answers
- PS-family ranking on the prefix-dedup tree: 1. risky_ps_old (0.117762).
- This tree preserves the original shared_basin_strong 4/5 minimal DAG connectivity and all original g values.
- The only structural change is parent-specific cloning of reused child aliases, so cross-prefix repeated agent identity is removed while local continuation patterns are unchanged.
- tree_spec_role_mode for this run: `spec_or_agent_id`.

## Old Theory-Aligned Reference
| method | regret_per_t_mean | terminal_proxy_mean | shared_path_fraction_mean | num_paths | horizon | seeds |
| --- | --- | --- | --- | --- | --- | --- |
| direct_multistage_exp3 | 0.0735857079360716 | 0.12053624211417821 | 0.98072 | 3125 | 5000 | 10 |
| risky_ps | 0.26536921693098714 | 0.31231975110909377 | 0.9079599999999999 | 3125 | 5000 | 10 |
| epsilon_exp3 | 0.26536921693098714 | 0.31231975110909377 | 0.9079599999999999 | 3125 | 5000 | 10 |
| naive_mixed | 0.34922459985788523 | 0.39617513403599186 | 0.02064 | 3125 | 5000 | 10 |
| random_path | 0.6295492983461468 | 0.6764998325242534 | 0.7983 | 3125 | 5000 | 10 |
