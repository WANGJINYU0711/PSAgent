# Prefix-dedup controlled simulation

- tree_spec_role_mode: `spec_or_agent_id`
- depth: `5`
- num_paths: `440`
- total_agent_ids: `655`
- duplicate_agent_count: `0`
- cross_prefix_duplicate_count: `0`

## Current Tree
| method | regret_per_t_mean | terminal_proxy_mean | shared_path_fraction_mean | num_paths | horizon | seeds |
| --- | --- | --- | --- | --- | --- | --- |
| direct_multistage_exp3 | 0.4849615594451055 | 0.5 | 0.9 | 440 | 50 | 1 |
| risky_ps | 0.5449615594451055 | 0.56 | 0.9 | 440 | 50 | 1 |
| random_path | 0.5849615594451055 | 0.6 | 0.94 | 440 | 50 | 1 |
| epsilon_exp3 | 0.6649615594451055 | 0.68 | 0.96 | 440 | 50 | 1 |

## Delta vs Old Theory-Aligned Partial 4/5 Reference
| method | delta_regret_per_t | delta_terminal_proxy | delta_shared_path_fraction |
| --- | --- | --- | --- |
| direct_multistage_exp3 | 0.4113758515090339 | 0.37946375788582176 | -0.08072000000000001 |
| risky_ps | 0.27959234251411835 | 0.24768024889090628 | -0.007959999999999856 |
| random_path | -0.044587738901041285 | -0.07649983252425341 | 0.14169999999999994 |
| epsilon_exp3 | 0.39959234251411835 | 0.3676802488909063 | 0.052040000000000086 |

## Direct Answers
- risky_ps vs epsilon_exp3 gap: -0.120000.
- risky_ps vs direct_multistage_exp3 gap: 0.060000.
- PS-family ranking on the prefix-dedup tree: 1. risky_ps (0.544962).
- Relative to old theory-aligned partial_4of5, the average risky_ps gap to epsilon/direct is smaller: current=-0.030000, old_theory=0.095892.
- This tree preserves the original shared_basin_strong 4/5 minimal DAG connectivity and all original g values.
- The only structural change is parent-specific cloning of reused child aliases, so cross-prefix repeated agent identity is removed while local continuation patterns are unchanged.
- tree_spec_role_mode for this run: `spec_or_agent_id`.

## Old Theory-Aligned Reference
| method | regret_per_t_mean | terminal_proxy_mean | shared_path_fraction_mean | num_paths | horizon | seeds |
| --- | --- | --- | --- | --- | --- | --- |
| direct_multistage_exp3 | 0.0735857079360716 | 0.12053624211417821 | 0.98072 | 3125 | 5000 | 10 |
| risky_ps | 0.26536921693098714 | 0.31231975110909377 | 0.9079599999999999 | 3125 | 5000 | 10 |
| epsilon_exp3 | 0.26536921693098714 | 0.31231975110909377 | 0.9079599999999999 | 3125 | 5000 | 10 |
| naive_mixed | 0.34922459985788523 | 0.39617513403599186 | 0.02064 | 3125 | 5000 | 10 |
| random_path | 0.6295492983461468 | 0.6764998325242534 | 0.7983 | 3125 | 5000 | 10 |
