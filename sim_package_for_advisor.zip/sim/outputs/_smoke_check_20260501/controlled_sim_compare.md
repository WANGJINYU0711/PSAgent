| setting | method_label | eta_shared | gamma_shared | num_paths | regret_per_t_mean | regret_per_t_std | average_cost_mean | exact_best_path_hit_rate_mean | shared_path_fraction_mean |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| shared_basin_strong_4of5_prefix_dedup | direct_multistage_exp3 | None | None | 440 | 0.4849615594451055 | 0.0 | 0.5 | 0.0 | 0.9 |
| shared_basin_strong_4of5_prefix_dedup | epsilon_exp3 | None | None | 440 | 0.6649615594451055 | 0.0 | 0.68 | 0.0 | 0.96 |
| shared_basin_strong_4of5_prefix_dedup | random_path | None | None | 440 | 0.5849615594451055 | 0.0 | 0.6 | 0.02 | 0.94 |
| shared_basin_strong_4of5_prefix_dedup | risky_ps | 0.05 | None | 440 | 0.5449615594451055 | 0.0 | 0.56 | 0.0 | 0.9 |
