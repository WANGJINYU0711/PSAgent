# PS-favored trap controlled simulation

- tree_spec_cost_mode: `ps_favored_trap`
- trap_basin_definition: `{'b1': 'stage1_n4', 'b2': ['stage2_n4', 'stage2_n5']}`
- trap_basin_leaf_count: `64`
- trap_path_base_aliases: `['stage1_n4', 'stage2_n5', 'stage3_n5', 'stage4_n5', 'stage5_n5']`
- exact_trap_path_exists: `True`
- trap_switch_denominator: `3`
- trap_switch_episode: `16`
- safe_basin_definition: `{'b3': ['stage3_n1', 'stage3_n2'], 'b4': 'stage4_n1', 'b5': ['stage5_n1', 'stage5_n2'], 'suffix_g': [0, 0, 0]}`
- cost_landscape_design: `v9_targeted_marginal_calibration`
- target_candidate_leaf_count: `16`
- target_good_leaf_count: `4`
- target_bad_leaf_count: `12`
- target_good_distribution_by_b3: `{'stage3_n1': 3, 'stage3_n2': 1}`
- target_good_distribution_by_b5: `{'stage5_n1': 3, 'stage5_n2': 1}`
- stage1_n3_stage2_n2_decoy_count: `13`
- stage1_n3_stage2_n3_decoy_count: `11`
- pre_calibration_stage1_n3_marginal: `{'stage2_n1': 0.42637129316555367, 'stage2_n2': 0.6540025002136509, 'stage2_n3': 0.647935864566299}`
- post_calibration_stage1_n3_marginal: `{'stage2_n1': 0.4755939145324865, 'stage2_n2': 0.5182668073633623, 'stage2_n3': 0.5227749251349743}`
- calibration_actions: `{'g2_decoy_count': 13, 'g3_decoy_count': 11, 'g1_target_bad_adjusted': True, 'g1_target_bad_adjusted_p_range': {'min': 0.9066924148854096, 'max': 0.9542547390354603}}`
- balancing_decoy_expected_p_range: `{'min': 0.20553348080467104, 'max': 0.2735675591425511}`
- root_child_marginal_expected_cost: `{'stage1_n1': 0.5738641681666345, 'stage1_n2': 0.5769362592416686, 'stage1_n3': 0.5178892101829062, 'stage1_n4': 0.6490784862348629, 'stage1_n5': 0.7724433913151513}`
- stage2_marginal_expected_cost: `{'stage1_n1': {'stage2_n1': 0.6268635509449241, 'stage2_n2': 0.5664918953702768, 'stage2_n3': 0.5750722851654784}, 'stage1_n2': {'stage2_n1': 0.6220658552971902, 'stage2_n2': 0.569193117631812, 'stage2_n3': 0.579522147695201}, 'stage1_n3': {'stage2_n1': 0.4755939145324865, 'stage2_n2': 0.5182668073633623, 'stage2_n3': 0.5227749251349743}}`
- exact_best_path: `['stage1_n3__from__root__c03', 'stage2_n1__from__n0003__c01', 'stage3_n2__from__n0012__c02', 'stage4_n1__from__n0042__c01', 'stage5_n1__from__n0121__c01']`
- exact_best_base_aliases: `['stage1_n3', 'stage2_n1', 'stage3_n2', 'stage4_n1', 'stage5_n1']`
- exact_best_expected_probability: `0.025`
- safe_basin_leaf_count: `24`
- safe_suffix_group_count: `4`
- oracle_best_leaf_type: `shared`
- oracle_best_is_shared: `True`
- target_ordering_met: `False`

## Method Results
| method | regret_per_t_mean | terminal_proxy_mean | shared_path_fraction_mean | trap_basin_fraction_mean | target_subtree_fraction_mean | target_good_fraction_mean | target_bad_fraction_mean | calibrated_decoy_fraction_mean | decoy_branch_fraction_mean | ordinary_safe_basin_fraction_mean | broad_safe_basin_fraction_mean | ps_favored_exact_best_hit_rate_mean | num_paths | horizon | seeds |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| direct_multistage_exp3 | 0.4849615594451055 | 0.5 | 0.9 | 0.06 | 0.12 | 0.04 | 0.08 | 0.08 | 0.24 | 0.06 | 0.18 | 0.0 | 440 | 50 | 1 |
| risky_ps | 0.5449615594451055 | 0.56 | 0.9 | 0.08 | 0.2 | 0.08 | 0.12 | 0.02 | 0.28 | 0.04 | 0.24 | 0.02 | 440 | 50 | 1 |
| random_path | 0.5849615594451055 | 0.6 | 0.94 | 0.08 | 0.22 | 0.08 | 0.14 | 0.04 | 0.24 | 0.06 | 0.28 | 0.02 | 440 | 50 | 1 |
| epsilon_exp3 | 0.6649615594451055 | 0.68 | 0.96 | 0.06 | 0.2 | 0.04 | 0.16 | 0.06 | 0.26 | 0.06 | 0.26 | 0.02 | 440 | 50 | 1 |

## Ordering Checks
| risky_ps_better_than_epsilon_exp3 | epsilon_exp3_better_than_direct_multistage_exp3 | target_ordering_met |
| --- | --- | --- |
| True | False | False |

## Top-10 Leaf Expected Probabilities
| rank | mean_probability | leaf_type | family_label | base_aliases |
| --- | --- | --- | --- | --- |
| 1 | 0.015038440554894535 | shared | ps_favored_v7_target_good | ['stage1_n1', 'stage2_n1', 'stage3_n1', 'stage4_n1', 'stage5_n2'] |
| 2 | 0.01642850420907608 | shared | ps_favored_v7_target_good | ['stage1_n3', 'stage2_n1', 'stage3_n1', 'stage4_n1', 'stage5_n1'] |
| 3 | 0.02120274476996339 | shared | ps_favored_v7_target_good | ['stage1_n2', 'stage2_n1', 'stage3_n1', 'stage4_n1', 'stage5_n1'] |
| 4 | 0.025 | shared | ps_favored_exact_best_hash_selected | ['stage1_n3', 'stage2_n1', 'stage3_n2', 'stage4_n1', 'stage5_n1'] |
| 5 | 0.20553348080467104 | shared | ps_favored_v9_balancing_candidate_base | ['stage1_n3', 'stage2_n3', 'stage3_n3', 'stage4_n2', 'stage5_n2'] |
| 6 | 0.2111916614685513 | shared | ps_favored_v9_balancing_candidate_base | ['stage1_n3', 'stage2_n2', 'stage3_n4', 'stage4_n3', 'stage5_n3'] |
| 7 | 0.21566042069561886 | shared | ps_favored_v9_balancing_candidate_base | ['stage1_n3', 'stage2_n3', 'stage3_n4', 'stage4_n4', 'stage5_n4'] |
| 8 | 0.21760795318316256 | shared | ps_favored_v9_balancing_candidate_base | ['stage1_n3', 'stage2_n2', 'stage3_n3', 'stage4_n3', 'stage5_n4'] |
| 9 | 0.2186029515038296 | shared | ps_favored_v9_balancing_candidate_base | ['stage1_n3', 'stage2_n3', 'stage3_n4', 'stage4_n4', 'stage5_n1'] |
| 10 | 0.22673531907491332 | shared | ps_favored_v9_balancing_candidate_base | ['stage1_n3', 'stage2_n2', 'stage3_n3', 'stage4_n3', 'stage5_n2'] |

## Top Safe Suffix Signatures
| signature | leaf_count | mean_probability |
| --- | --- | --- |
| ['stage3_n2', 'stage4_n1', 'stage5_n2'] | 8 | 0.6899800700429236 |
| ['stage3_n2', 'stage4_n1', 'stage5_n1'] | 8 | 0.5331935975047116 |
| ['stage3_n1', 'stage4_n1', 'stage5_n2'] | 4 | 0.6325098285973794 |
| ['stage3_n1', 'stage4_n1', 'stage5_n1'] | 4 | 0.4325316442430633 |
