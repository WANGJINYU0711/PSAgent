| method | regret_per_t_mean | average_cost_mean | shared_path_fraction_mean | num_paths | horizon | seeds |
| --- | --- | --- | --- | --- | --- | --- |
| direct_multistage_exp3 | 0.4849615594451055 | 0.5 | 0.9 | 440 | 50 | 1 |
| risky_ps | 0.5449615594451055 | 0.56 | 0.9 | 440 | 50 | 1 |
| random_path | 0.5849615594451055 | 0.6 | 0.94 | 440 | 50 | 1 |
| epsilon_exp3 | 0.6649615594451055 | 0.68 | 0.96 | 440 | 50 | 1 |
