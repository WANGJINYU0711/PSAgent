| method | regret_per_t_mean | terminal_proxy_mean | shared_path_fraction_mean | trap_basin_fraction_mean | target_subtree_fraction_mean | target_good_fraction_mean | target_bad_fraction_mean | calibrated_decoy_fraction_mean | decoy_branch_fraction_mean | ordinary_safe_basin_fraction_mean | broad_safe_basin_fraction_mean | ps_favored_exact_best_hit_rate_mean | num_paths | horizon | seeds |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| direct_multistage_exp3 | 0.4849615594451055 | 0.5 | 0.9 | 0.06 | 0.12 | 0.04 | 0.08 | 0.08 | 0.24 | 0.06 | 0.18 | 0.0 | 440 | 50 | 1 |
| risky_ps | 0.5449615594451055 | 0.56 | 0.9 | 0.08 | 0.2 | 0.08 | 0.12 | 0.02 | 0.28 | 0.04 | 0.24 | 0.02 | 440 | 50 | 1 |
| random_path | 0.5849615594451055 | 0.6 | 0.94 | 0.08 | 0.22 | 0.08 | 0.14 | 0.04 | 0.24 | 0.06 | 0.28 | 0.02 | 440 | 50 | 1 |
| epsilon_exp3 | 0.6649615594451055 | 0.68 | 0.96 | 0.06 | 0.2 | 0.04 | 0.16 | 0.06 | 0.26 | 0.06 | 0.26 | 0.02 | 440 | 50 | 1 |
