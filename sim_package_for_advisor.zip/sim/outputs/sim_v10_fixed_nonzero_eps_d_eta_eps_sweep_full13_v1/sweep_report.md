# sim_v10 nonzero-eps d/eta/eps sweep full13 v1

## Setting

- experiment_name: `sim_v10_fixed_nonzero_eps_d_eta_eps_sweep_full13_v1`
- tree_spec: `/home/ubuntu/data/PSAgent/analysis/tree_specs/shared_basin_strong_4of5_prefix_dedup.json`
- tree_spec_role_mode: `spec_or_agent_id`
- tree_spec_cost_mode: `ps_favored_trap_v10_avg_baited`
- d values: `[5, 6, 7, 8, 10, 12, 16]`
- eta values: `[0.05, 0.1, 0.15, 0.2, 0.3, 0.4, 0.5]`
- epsilon values: `[0.005, 0.01, 0.02, 0.05, 0.1]`
- horizon: `1000`
- seeds: `[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]`
- methods: `13`

Primary ranking here is post-switch avg regret, then tail20 avg cost, then regret/T.

## Coverage

- completed combos: `245` / `245`
- rows: `3185`
- post-switch PS-winning combos: `6` / `245`
- overall PS-winning combos: `2` / `245`

## Best By Method, Post-Switch Primary

| best_post_switch_rank | method | d | switch_episode | eta_sweep | epsilon_sweep | post_switch_avg_regret_mean | tail20_avg_total_cost_mean | regret_per_t_mean | overall_avg_total_cost_mean | target_good_fraction_mean | trap_basin_fraction_mean | shared_path_fraction_mean |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | naive_mixed_avg | 16 | 62 | 0.050000 | 0.005000 | 0.022196 | 0.010000 | 0.018573 | 0.031900 | 0.926300 | 0.000000 | 1.000000 |
| 2 | direct_multistage_exp3 | 16 | 62 | 0.500000 | 0.005000 | 0.040426 | 0.005000 | 0.047273 | 0.060600 | 0.904500 | 0.018800 | 0.992800 |
| 3 | epsilon_exp3 | 16 | 62 | 0.500000 | 0.005000 | 0.051834 | 0.015000 | 0.059773 | 0.073100 | 0.888800 | 0.013800 | 0.991900 |
| 4 | risky_ps_old | 16 | 62 | 0.500000 | 0.005000 | 0.054179 | 0.020000 | 0.060473 | 0.073800 | 0.883900 | 0.012200 | 0.994000 |
| 5 | direct_multistage_exp3_local | 12 | 83 | 0.500000 | 0.005000 | 0.058157 | 0.015000 | 0.065946 | 0.080400 | 0.861700 | 0.031900 | 0.991100 |
| 6 | risky_ps_linear | 16 | 62 | 0.300000 | 0.005000 | 0.058337 | 0.000000 | 0.066073 | 0.079400 | 0.881800 | 0.012600 | 0.992200 |
| 7 | risky_ps | 10 | 100 | 0.300000 | 0.005000 | 0.076778 | 0.005000 | 0.080634 | 0.096000 | 0.826200 | 0.020000 | 0.990800 |
| 8 | risky_ps_ix | 8 | 125 | 0.300000 | 0.005000 | 0.080514 | 0.010000 | 0.082392 | 0.099100 | 0.812200 | 0.025900 | 0.989600 |
| 9 | risky_ps_safe_conditional | 16 | 62 | 0.500000 | 0.005000 | 0.096183 | 0.020000 | 0.099873 | 0.113200 | 0.837300 | 0.014600 | 0.991300 |
| 10 | risky_ps_safe_conditional_ix | 16 | 62 | 0.500000 | 0.005000 | 0.099701 | 0.025000 | 0.103173 | 0.116500 | 0.831500 | 0.014700 | 0.991100 |
| 11 | risky_ps_direct_cost | 16 | 62 | 0.300000 | 0.010000 | 0.280299 | 0.065000 | 0.274473 | 0.287800 | 0.627200 | 0.019200 | 0.984100 |
| 12 | random_path | 7 | 142 | 0.050000 | 0.005000 | 0.751538 | 0.755000 | 0.689980 | 0.707600 | 0.072000 | 0.079200 | 0.929300 |
| 13 | naive_mixed | 16 | 62 | 0.050000 | 0.005000 | 0.814520 | 0.905000 | 0.761273 | 0.774600 | 0.081200 | 0.000000 | 1.000000 |

## Best By Method, Overall regret/T

| best_overall_rank | method | d | switch_episode | eta_sweep | epsilon_sweep | regret_per_t_mean | overall_avg_total_cost_mean | post_switch_avg_regret_mean | tail20_avg_total_cost_mean | target_good_fraction_mean | trap_basin_fraction_mean | shared_path_fraction_mean |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | naive_mixed_avg | 16 | 62 | 0.050000 | 0.005000 | 0.018573 | 0.031900 | 0.022196 | 0.010000 | 0.926300 | 0.000000 | 1.000000 |
| 2 | direct_multistage_exp3 | 16 | 62 | 0.500000 | 0.005000 | 0.047273 | 0.060600 | 0.040426 | 0.005000 | 0.904500 | 0.018800 | 0.992800 |
| 3 | risky_ps_old | 6 | 166 | 0.400000 | 0.005000 | 0.056792 | 0.075700 | 0.057746 | 0.025000 | 0.801200 | 0.037200 | 0.990500 |
| 4 | epsilon_exp3 | 16 | 62 | 0.500000 | 0.005000 | 0.059773 | 0.073100 | 0.051834 | 0.015000 | 0.888800 | 0.013800 | 0.991900 |
| 5 | direct_multistage_exp3_local | 12 | 83 | 0.500000 | 0.005000 | 0.065946 | 0.080400 | 0.058157 | 0.015000 | 0.861700 | 0.031900 | 0.991100 |
| 6 | risky_ps_linear | 16 | 62 | 0.300000 | 0.005000 | 0.066073 | 0.079400 | 0.058337 | 0.000000 | 0.881800 | 0.012600 | 0.992200 |
| 7 | risky_ps | 8 | 125 | 0.300000 | 0.005000 | 0.079892 | 0.096600 | 0.077657 | 0.010000 | 0.814400 | 0.025900 | 0.989000 |
| 8 | risky_ps_ix | 8 | 125 | 0.300000 | 0.005000 | 0.082392 | 0.099100 | 0.080514 | 0.010000 | 0.812200 | 0.025900 | 0.989600 |
| 9 | risky_ps_safe_conditional | 16 | 62 | 0.500000 | 0.005000 | 0.099873 | 0.113200 | 0.096183 | 0.020000 | 0.837300 | 0.014600 | 0.991300 |
| 10 | risky_ps_safe_conditional_ix | 16 | 62 | 0.500000 | 0.005000 | 0.103173 | 0.116500 | 0.099701 | 0.025000 | 0.831500 | 0.014700 | 0.991100 |
| 11 | risky_ps_direct_cost | 7 | 142 | 0.200000 | 0.010000 | 0.266280 | 0.283900 | 0.294079 | 0.065000 | 0.577200 | 0.039500 | 0.982100 |
| 12 | random_path | 5 | 200 | 0.050000 | 0.005000 | 0.664767 | 0.685500 | 0.752875 | 0.755000 | 0.072000 | 0.079200 | 0.929300 |
| 13 | naive_mixed | 5 | 200 | 0.050000 | 0.005000 | 0.675367 | 0.696100 | 0.855875 | 0.905000 | 0.040900 | 0.000000 | 1.000000 |

## Top PS-Winning Post-Switch Configs

| d | switch_episode | eta | epsilon | best_post_switch_method | best_post_switch_regret | best_ps_post_method | best_ps_post_rank | best_ps_post_switch_regret | best_ps_post_minus_direct | best_ps_post_minus_direct_local | best_ps_post_minus_epsilon_exp3 | best_ps_post_minus_naive_mixed_avg | best_ps_tail20 | best_ps_regret_per_t | best_ps_target_good | best_ps_trap |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 6 | 166 | 0.400000 | 0.005000 | risky_ps_old | 0.057746 | risky_ps_old | 1 | 0.057746 | -0.093885 | -0.030815 | -0.018225 | -0.030935 | 0.025000 | 0.056792 | 0.801200 | 0.037200 |
| 5 | 200 | 0.400000 | 0.005000 | risky_ps_old | 0.063875 | risky_ps_old | 1 | 0.063875 | -0.057750 | -0.035250 | -0.041875 | -0.025500 | 0.025000 | 0.058667 | 0.773500 | 0.044200 |
| 6 | 166 | 0.300000 | 0.010000 | risky_ps_old | 0.069496 | risky_ps_old | 1 | 0.069496 | -0.000480 | -0.058034 | -0.038129 | -0.019185 | 0.030000 | 0.068492 | 0.793800 | 0.030200 |
| 5 | 200 | 0.400000 | 0.010000 | risky_ps_old | 0.076750 | risky_ps_old | 1 | 0.076750 | -0.044875 | -0.022375 | -0.019000 | -0.012625 | 0.045000 | 0.068867 | 0.762000 | 0.043400 |
| 5 | 200 | 0.300000 | 0.010000 | risky_ps_old | 0.077250 | risky_ps_old | 1 | 0.077250 | -0.006625 | -0.036625 | -0.022000 | -0.012125 | 0.010000 | 0.070967 | 0.761400 | 0.037300 |
| 6 | 166 | 0.400000 | 0.010000 | risky_ps_old | 0.079568 | risky_ps_old | 1 | 0.079568 | -0.072062 | -0.008993 | -0.011151 | -0.009113 | 0.020000 | 0.075092 | 0.781800 | 0.038700 |

## Top Post-Switch Configs Across All Methods

| d | switch_episode | eta | epsilon | best_post_switch_method | best_post_switch_regret | best_ps_post_method | best_ps_post_rank | best_ps_post_switch_regret | best_ps_post_minus_direct | best_ps_post_minus_direct_local | best_ps_post_minus_epsilon_exp3 | best_ps_post_minus_naive_mixed_avg | best_ps_tail20 | best_ps_regret_per_t | best_ps_target_good | best_ps_trap |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 16 | 62 | 0.500000 | 0.005000 | naive_mixed_avg | 0.022196 | risky_ps_old | 4 | 0.054179 | 0.013753 | -0.010661 | 0.002345 | 0.031983 | 0.020000 | 0.060473 | 0.883900 | 0.012200 |
| 16 | 62 | 0.300000 | 0.005000 | naive_mixed_avg | 0.022196 | risky_ps_old | 3 | 0.054712 | 0.000107 | -0.015885 | -0.023454 | 0.032516 | 0.020000 | 0.062673 | 0.886200 | 0.010800 |
| 16 | 62 | 0.200000 | 0.005000 | naive_mixed_avg | 0.022196 | risky_ps_old | 3 | 0.060256 | 0.001066 | -0.035181 | -0.024627 | 0.038060 | 0.025000 | 0.068073 | 0.880400 | 0.013700 |
| 16 | 62 | 0.500000 | 0.020000 | naive_mixed_avg | 0.022196 | risky_ps_old | 3 | 0.060789 | 0.020362 | -0.004051 | -0.011301 | 0.038593 | 0.040000 | 0.067073 | 0.876600 | 0.012000 |
| 16 | 62 | 0.300000 | 0.010000 | naive_mixed_avg | 0.022196 | risky_ps_old | 3 | 0.061215 | 0.006610 | -0.009382 | -0.025693 | 0.039019 | 0.020000 | 0.068773 | 0.878800 | 0.011300 |
| 16 | 62 | 0.200000 | 0.010000 | naive_mixed_avg | 0.022196 | risky_ps_old | 3 | 0.063241 | 0.004051 | -0.032196 | -0.014712 | 0.041045 | 0.020000 | 0.070973 | 0.872600 | 0.013900 |
| 16 | 62 | 0.500000 | 0.010000 | naive_mixed_avg | 0.022196 | risky_ps_old | 4 | 0.063987 | 0.023561 | -0.000853 | 0.003838 | 0.041791 | 0.025000 | 0.069773 | 0.872300 | 0.012600 |
| 16 | 62 | 0.150000 | 0.005000 | naive_mixed_avg | 0.022196 | risky_ps_linear | 3 | 0.064733 | 0.003731 | -0.028785 | -0.011940 | 0.042537 | 0.010000 | 0.073973 | 0.871900 | 0.018700 |
| 16 | 62 | 0.150000 | 0.010000 | naive_mixed_avg | 0.022196 | risky_ps_linear | 3 | 0.068252 | 0.007249 | -0.025267 | -0.014072 | 0.046055 | 0.020000 | 0.077273 | 0.868400 | 0.019200 |
| 16 | 62 | 0.100000 | 0.005000 | naive_mixed_avg | 0.022196 | risky_ps_linear | 2 | 0.070490 | -0.002772 | -0.050213 | -0.012367 | 0.048294 | 0.005000 | 0.080773 | 0.864100 | 0.014500 |
| 16 | 62 | 0.400000 | 0.005000 | naive_mixed_avg | 0.022196 | risky_ps_old | 5 | 0.070917 | 0.023987 | 0.002559 | 0.000107 | 0.048721 | 0.015000 | 0.077573 | 0.870100 | 0.016100 |
| 16 | 62 | 0.400000 | 0.010000 | naive_mixed_avg | 0.022196 | risky_ps_old | 4 | 0.075928 | 0.028998 | 0.007569 | -0.007889 | 0.053731 | 0.040000 | 0.082273 | 0.862900 | 0.016500 |
| 16 | 62 | 0.100000 | 0.010000 | naive_mixed_avg | 0.022196 | risky_ps_linear | 3 | 0.076567 | 0.003305 | -0.044136 | -0.012473 | 0.054371 | 0.015000 | 0.086473 | 0.860900 | 0.015000 |
| 16 | 62 | 0.300000 | 0.020000 | naive_mixed_avg | 0.022196 | risky_ps_old | 4 | 0.076674 | 0.022068 | 0.006077 | -0.032942 | 0.054478 | 0.055000 | 0.083373 | 0.858700 | 0.013200 |
| 16 | 62 | 0.400000 | 0.020000 | naive_mixed_avg | 0.022196 | risky_ps_old | 4 | 0.078913 | 0.031983 | 0.010554 | -0.011727 | 0.056716 | 0.040000 | 0.085273 | 0.855300 | 0.016100 |
| 16 | 62 | 0.150000 | 0.020000 | naive_mixed_avg | 0.022196 | risky_ps_linear | 3 | 0.080405 | 0.019403 | -0.013113 | -0.016098 | 0.058209 | 0.060000 | 0.088873 | 0.852400 | 0.017700 |
| 16 | 62 | 0.200000 | 0.020000 | naive_mixed_avg | 0.022196 | risky_ps_linear | 3 | 0.080618 | 0.021429 | -0.014819 | -0.004584 | 0.058422 | 0.025000 | 0.088073 | 0.849300 | 0.014400 |
| 16 | 62 | 0.100000 | 0.020000 | naive_mixed_avg | 0.022196 | risky_ps_linear | 3 | 0.085629 | 0.012367 | -0.035075 | -0.013859 | 0.063433 | 0.050000 | 0.094873 | 0.846300 | 0.015800 |
| 16 | 62 | 0.400000 | 0.050000 | naive_mixed_avg | 0.022196 | risky_ps_old | 4 | 0.087015 | 0.040085 | 0.018657 | -0.043710 | 0.064819 | 0.040000 | 0.092573 | 0.840300 | 0.014600 |
| 16 | 62 | 0.500000 | 0.050000 | naive_mixed_avg | 0.022196 | risky_ps_old | 4 | 0.088934 | 0.048507 | 0.024094 | -0.035928 | 0.066738 | 0.055000 | 0.093973 | 0.840200 | 0.014300 |

## Top PS-Winning Overall Configs

| d | switch_episode | eta | epsilon | best_overall_method | best_overall_regret_per_t | best_ps_overall_method | best_ps_overall_rank | best_ps_overall_regret_per_t | best_ps_overall_minus_direct | best_ps_overall_minus_direct_local | best_ps_overall_minus_epsilon_exp3 | best_ps_overall_minus_naive_mixed_avg |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 6 | 166 | 0.400000 | 0.005000 | risky_ps_old | 0.056792 | risky_ps_old | 1 | 0.056792 | -0.077600 | -0.028500 | -0.015200 | -0.010400 |
| 5 | 200 | 0.400000 | 0.005000 | risky_ps_old | 0.058667 | risky_ps_old | 1 | 0.058667 | -0.045300 | -0.031000 | -0.033300 | -0.004900 |

## Output Files

- `sweep_results_long.csv/json`: every method at every `(d, eta, eps)`
- `sweep_results_long_primary_metrics.csv`: compact long table
- `combo_summaries.csv/json`: one row per `(d, eta, eps)` with PS-vs-baseline margins
- `best_by_method_post_switch.csv/json`: best setting for each method by post-switch metric
- `best_by_method_overall.csv/json`: best setting for each method by regret/T
- `top_ps_winning_post_switch_configs.csv`: PS-winning configs sorted by post-switch quality
