# Eta x Epsilon Sweep Summary

## Ranking Table

| eta | epsilon | best_ps_method | best_ps_regret/T | direct_regret/T | epsilon_exp3_regret/T | risky_ps_old | risky_ps | risky_ps_ix | risky_ps_safe_conditional | risky_ps_safe_conditional_ix | risky_ps_direct_cost | ranking |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 0.01 | 0 | risky_ps | 0.244762 | 0.328762 | 0.328762 | 0.331162 | 0.244762 | 0.254162 | 0.411562 | 0.411762 | 0.479962 | risky_ps < risky_ps_ix < direct_multistage_exp3 < epsilon_exp3 < risky_ps_old < risky_ps_safe_conditional < risky_ps_safe_conditional_ix < risky_ps_direct_cost < random_path < naive_mixed |
| 0.01 | 0.02 | risky_ps | 0.255562 | 0.328762 | 0.329162 | 0.325962 | 0.255562 | 0.258362 | 0.415362 | 0.419562 | 0.501162 | risky_ps < risky_ps_ix < risky_ps_old < direct_multistage_exp3 < epsilon_exp3 < risky_ps_safe_conditional < risky_ps_safe_conditional_ix < risky_ps_direct_cost < random_path < naive_mixed |
| 0.01 | 0.05 | risky_ps | 0.259762 | 0.328762 | 0.345362 | 0.331562 | 0.259762 | 0.266762 | 0.411362 | 0.411962 | 0.508562 | risky_ps < risky_ps_ix < direct_multistage_exp3 < risky_ps_old < epsilon_exp3 < risky_ps_safe_conditional < risky_ps_safe_conditional_ix < risky_ps_direct_cost < random_path < naive_mixed |
| 0.01 | 0.1 | risky_ps | 0.275362 | 0.328762 | 0.368562 | 0.355962 | 0.275362 | 0.282562 | 0.427762 | 0.427562 | 0.526962 | risky_ps < risky_ps_ix < direct_multistage_exp3 < risky_ps_old < epsilon_exp3 < risky_ps_safe_conditional_ix < risky_ps_safe_conditional < risky_ps_direct_cost < random_path < naive_mixed |
| 0.01 | 0.2 | risky_ps | 0.294562 | 0.328762 | 0.420762 | 0.368962 | 0.294562 | 0.301562 | 0.437962 | 0.438962 | 0.522362 | risky_ps < risky_ps_ix < direct_multistage_exp3 < risky_ps_old < epsilon_exp3 < risky_ps_safe_conditional < risky_ps_safe_conditional_ix < risky_ps_direct_cost < random_path < naive_mixed |
| 0.02 | 0 | risky_ps | 0.180162 | 0.215962 | 0.215962 | 0.222962 | 0.180162 | 0.185162 | 0.337562 | 0.336962 | 0.453762 | risky_ps < risky_ps_ix < direct_multistage_exp3 < epsilon_exp3 < risky_ps_old < risky_ps_safe_conditional_ix < risky_ps_safe_conditional < risky_ps_direct_cost < random_path < naive_mixed |
| 0.02 | 0.02 | risky_ps | 0.183362 | 0.215962 | 0.228362 | 0.219962 | 0.183362 | 0.189762 | 0.348162 | 0.345962 | 0.483162 | risky_ps < risky_ps_ix < direct_multistage_exp3 < risky_ps_old < epsilon_exp3 < risky_ps_safe_conditional_ix < risky_ps_safe_conditional < risky_ps_direct_cost < random_path < naive_mixed |
| 0.02 | 0.05 | risky_ps | 0.187562 | 0.215962 | 0.247762 | 0.230162 | 0.187562 | 0.194762 | 0.358362 | 0.358362 | 0.468562 | risky_ps < risky_ps_ix < direct_multistage_exp3 < risky_ps_old < epsilon_exp3 < risky_ps_safe_conditional < risky_ps_safe_conditional_ix < risky_ps_direct_cost < random_path < naive_mixed |
| 0.02 | 0.1 | risky_ps | 0.212562 | 0.215962 | 0.283762 | 0.240562 | 0.212562 | 0.219562 | 0.365162 | 0.368362 | 0.494362 | risky_ps < direct_multistage_exp3 < risky_ps_ix < risky_ps_old < epsilon_exp3 < risky_ps_safe_conditional < risky_ps_safe_conditional_ix < risky_ps_direct_cost < random_path < naive_mixed |
| 0.02 | 0.2 | risky_ps | 0.238162 | 0.215962 | 0.338162 | 0.277562 | 0.238162 | 0.246962 | 0.372962 | 0.372962 | 0.469162 | direct_multistage_exp3 < risky_ps < risky_ps_ix < risky_ps_old < epsilon_exp3 < risky_ps_safe_conditional < risky_ps_safe_conditional_ix < risky_ps_direct_cost < random_path < naive_mixed |
| 0.05 | 0 | risky_ps_old | 0.144962 | 0.136162 | 0.136162 | 0.144962 | 0.144962 | 0.146162 | 0.313362 | 0.313562 | 0.405762 | direct_multistage_exp3 < epsilon_exp3 < risky_ps < risky_ps_old < risky_ps_ix < risky_ps_safe_conditional < risky_ps_safe_conditional_ix < risky_ps_direct_cost < random_path < naive_mixed |
| 0.05 | 0.02 | risky_ps_old | 0.141962 | 0.136162 | 0.169762 | 0.141962 | 0.141962 | 0.148562 | 0.283562 | 0.284162 | 0.372562 | direct_multistage_exp3 < risky_ps < risky_ps_old < risky_ps_ix < epsilon_exp3 < risky_ps_safe_conditional < risky_ps_safe_conditional_ix < risky_ps_direct_cost < random_path < naive_mixed |
| 0.05 | 0.05 | risky_ps_ix | 0.150762 | 0.136162 | 0.182762 | 0.157962 | 0.157962 | 0.150762 | 0.383162 | 0.383362 | 0.407162 | direct_multistage_exp3 < risky_ps_ix < risky_ps < risky_ps_old < epsilon_exp3 < risky_ps_safe_conditional < risky_ps_safe_conditional_ix < risky_ps_direct_cost < random_path < naive_mixed |
| 0.05 | 0.1 | risky_ps_ix | 0.172762 | 0.136162 | 0.221562 | 0.174162 | 0.174162 | 0.172762 | 0.320962 | 0.320962 | 0.388362 | direct_multistage_exp3 < risky_ps_ix < risky_ps < risky_ps_old < epsilon_exp3 < risky_ps_safe_conditional < risky_ps_safe_conditional_ix < risky_ps_direct_cost < random_path < naive_mixed |
| 0.05 | 0.2 | risky_ps_old | 0.203362 | 0.136162 | 0.277762 | 0.203362 | 0.203362 | 0.207762 | 0.332762 | 0.332762 | 0.424562 | direct_multistage_exp3 < risky_ps < risky_ps_old < risky_ps_ix < epsilon_exp3 < risky_ps_safe_conditional < risky_ps_safe_conditional_ix < risky_ps_direct_cost < random_path < naive_mixed |
| 0.1 | 0 | risky_ps_old | 0.115562 | 0.133362 | 0.133362 | 0.115562 | 0.150762 | 0.146762 | 0.278162 | 0.280362 | 0.349362 | risky_ps_old < direct_multistage_exp3 < epsilon_exp3 < risky_ps_ix < risky_ps < risky_ps_safe_conditional < risky_ps_safe_conditional_ix < risky_ps_direct_cost < random_path < naive_mixed |
| 0.1 | 0.02 | risky_ps | 0.131562 | 0.133362 | 0.124962 | 0.132162 | 0.131562 | 0.157762 | 0.231362 | 0.230362 | 0.327762 | epsilon_exp3 < risky_ps < risky_ps_old < direct_multistage_exp3 < risky_ps_ix < risky_ps_safe_conditional_ix < risky_ps_safe_conditional < risky_ps_direct_cost < random_path < naive_mixed |
| 0.1 | 0.05 | risky_ps_old | 0.112962 | 0.133362 | 0.162962 | 0.112962 | 0.134162 | 0.146562 | 0.360362 | 0.354562 | 0.397562 | risky_ps_old < direct_multistage_exp3 < risky_ps < risky_ps_ix < epsilon_exp3 < risky_ps_safe_conditional_ix < risky_ps_safe_conditional < risky_ps_direct_cost < random_path < naive_mixed |
| 0.1 | 0.1 | risky_ps_old | 0.152562 | 0.133362 | 0.212762 | 0.152562 | 0.160762 | 0.173962 | 0.256362 | 0.256362 | 0.379562 | direct_multistage_exp3 < risky_ps_old < risky_ps < risky_ps_ix < epsilon_exp3 < risky_ps_safe_conditional < risky_ps_safe_conditional_ix < risky_ps_direct_cost < random_path < naive_mixed |
| 0.1 | 0.2 | risky_ps_old | 0.188562 | 0.133362 | 0.276362 | 0.188562 | 0.199562 | 0.193362 | 0.324562 | 0.324762 | 0.399162 | direct_multistage_exp3 < risky_ps_old < risky_ps_ix < risky_ps < epsilon_exp3 < risky_ps_safe_conditional < risky_ps_safe_conditional_ix < risky_ps_direct_cost < random_path < naive_mixed |
| 0.2 | 0 | risky_ps_old | 0.089162 | 0.103962 | 0.103962 | 0.089162 | 0.113962 | 0.137762 | 0.197362 | 0.199562 | 0.319362 | risky_ps_old < direct_multistage_exp3 < epsilon_exp3 < risky_ps < risky_ps_ix < risky_ps_safe_conditional < risky_ps_safe_conditional_ix < risky_ps_direct_cost < random_path < naive_mixed |
| 0.2 | 0.02 | risky_ps_old | 0.095162 | 0.103962 | 0.119162 | 0.095162 | 0.132962 | 0.132562 | 0.232562 | 0.232562 | 0.366962 | risky_ps_old < direct_multistage_exp3 < epsilon_exp3 < risky_ps_ix < risky_ps < risky_ps_safe_conditional < risky_ps_safe_conditional_ix < risky_ps_direct_cost < random_path < naive_mixed |
| 0.2 | 0.05 | risky_ps_old | 0.096162 | 0.103962 | 0.140562 | 0.096162 | 0.147562 | 0.143362 | 0.226562 | 0.226562 | 0.334762 | risky_ps_old < direct_multistage_exp3 < epsilon_exp3 < risky_ps_ix < risky_ps < risky_ps_safe_conditional < risky_ps_safe_conditional_ix < risky_ps_direct_cost < random_path < naive_mixed |
| 0.2 | 0.1 | risky_ps_old | 0.127562 | 0.103962 | 0.169362 | 0.127562 | 0.158362 | 0.170362 | 0.236762 | 0.234762 | 0.366162 | direct_multistage_exp3 < risky_ps_old < risky_ps < epsilon_exp3 < risky_ps_ix < risky_ps_safe_conditional_ix < risky_ps_safe_conditional < risky_ps_direct_cost < random_path < naive_mixed |
| 0.2 | 0.2 | risky_ps_old | 0.176962 | 0.103962 | 0.253362 | 0.176962 | 0.195362 | 0.192762 | 0.308562 | 0.308362 | 0.374362 | direct_multistage_exp3 < risky_ps_old < risky_ps_ix < risky_ps < epsilon_exp3 < risky_ps_safe_conditional_ix < risky_ps_safe_conditional < risky_ps_direct_cost < random_path < naive_mixed |

## Tail/Post-switch Diagnostics

| eta | epsilon | best_ps_method | best_ps_overall_avg_total_cost | best_ps_tail20_avg_total_cost | best_ps_post_switch_avg_regret | best_ps_tail_window_avg_cost | direct_overall_avg_total_cost | direct_tail20_avg_total_cost | direct_post_switch_avg_regret | epsilon_overall_avg_total_cost | epsilon_tail20_avg_total_cost | epsilon_post_switch_avg_regret |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 0.01 | 0 | risky_ps | 0.259800 | 0.060000 | 0.185561 | 0.060000 | 0.343800 | 0.090000 | 0.289309 | 0.343800 | 0.090000 | 0.289309 |
| 0.01 | 0.02 | risky_ps | 0.270600 | 0.090000 | 0.191558 | 0.090000 | 0.343800 | 0.090000 | 0.289309 | 0.344200 | 0.060000 | 0.286311 |
| 0.01 | 0.05 | risky_ps | 0.274800 | 0.080000 | 0.204152 | 0.080000 | 0.343800 | 0.090000 | 0.289309 | 0.360400 | 0.200000 | 0.307600 |
| 0.01 | 0.1 | risky_ps | 0.290400 | 0.090000 | 0.220644 | 0.090000 | 0.343800 | 0.090000 | 0.289309 | 0.383600 | 0.210000 | 0.337885 |
| 0.01 | 0.2 | risky_ps | 0.309600 | 0.100000 | 0.248830 | 0.100000 | 0.343800 | 0.090000 | 0.289309 | 0.435800 | 0.290000 | 0.409549 |
| 0.02 | 0 | risky_ps | 0.195200 | 0.030000 | 0.119294 | 0.030000 | 0.231000 | 0.020000 | 0.163672 | 0.231000 | 0.020000 | 0.163672 |
| 0.02 | 0.02 | risky_ps | 0.198400 | 0.080000 | 0.115696 | 0.080000 | 0.231000 | 0.020000 | 0.163672 | 0.243400 | 0.050000 | 0.178365 |
| 0.02 | 0.05 | risky_ps | 0.202600 | 0.030000 | 0.123492 | 0.030000 | 0.231000 | 0.020000 | 0.163672 | 0.262800 | 0.110000 | 0.203552 |
| 0.02 | 0.1 | risky_ps | 0.227600 | 0.060000 | 0.155576 | 0.060000 | 0.231000 | 0.020000 | 0.163672 | 0.298800 | 0.170000 | 0.248830 |
| 0.02 | 0.2 | risky_ps | 0.253200 | 0.100000 | 0.187061 | 0.100000 | 0.231000 | 0.020000 | 0.163672 | 0.353200 | 0.280000 | 0.317795 |
| 0.05 | 0 | risky_ps_old | 0.160000 | 0.010000 | 0.123792 | 0.010000 | 0.151200 | 0.030000 | 0.112398 | 0.151200 | 0.030000 | 0.112398 |
| 0.05 | 0.02 | risky_ps_old | 0.157000 | 0.050000 | 0.108500 | 0.050000 | 0.151200 | 0.030000 | 0.112398 | 0.184800 | 0.010000 | 0.147480 |
| 0.05 | 0.05 | risky_ps_ix | 0.165800 | 0.060000 | 0.115096 | 0.060000 | 0.151200 | 0.030000 | 0.112398 | 0.197800 | 0.120000 | 0.164272 |
| 0.05 | 0.1 | risky_ps_ix | 0.187800 | 0.030000 | 0.138485 | 0.030000 | 0.151200 | 0.030000 | 0.112398 | 0.236600 | 0.170000 | 0.207450 |
| 0.05 | 0.2 | risky_ps_old | 0.218400 | 0.130000 | 0.168770 | 0.130000 | 0.151200 | 0.030000 | 0.112398 | 0.292800 | 0.190000 | 0.274317 |
| 0.1 | 0 | risky_ps_old | 0.130600 | 0.010000 | 0.113597 | 0.010000 | 0.148400 | 0.040000 | 0.140584 | 0.148400 | 0.040000 | 0.140584 |
| 0.1 | 0.02 | risky_ps | 0.146600 | 0.030000 | 0.122593 | 0.030000 | 0.148400 | 0.040000 | 0.140584 | 0.140000 | 0.000000 | 0.116296 |
| 0.1 | 0.05 | risky_ps_old | 0.128000 | 0.020000 | 0.088410 | 0.020000 | 0.148400 | 0.040000 | 0.140584 | 0.178000 | 0.110000 | 0.163073 |
| 0.1 | 0.1 | risky_ps_old | 0.167600 | 0.080000 | 0.139684 | 0.080000 | 0.148400 | 0.040000 | 0.140584 | 0.227800 | 0.190000 | 0.225141 |
| 0.1 | 0.2 | risky_ps_old | 0.203600 | 0.070000 | 0.171168 | 0.070000 | 0.148400 | 0.040000 | 0.140584 | 0.291400 | 0.190000 | 0.294707 |
| 0.2 | 0 | risky_ps_old | 0.104200 | 0.040000 | 0.091408 | 0.040000 | 0.119000 | 0.010000 | 0.113897 | 0.119000 | 0.010000 | 0.113897 |
| 0.2 | 0.02 | risky_ps_old | 0.110200 | 0.020000 | 0.089609 | 0.020000 | 0.119000 | 0.010000 | 0.113897 | 0.134200 | 0.030000 | 0.127990 |
| 0.2 | 0.05 | risky_ps_old | 0.111200 | 0.060000 | 0.081513 | 0.060000 | 0.119000 | 0.010000 | 0.113897 | 0.155600 | 0.080000 | 0.145081 |
| 0.2 | 0.1 | risky_ps_old | 0.142600 | 0.070000 | 0.108500 | 0.070000 | 0.119000 | 0.010000 | 0.113897 | 0.184400 | 0.170000 | 0.172068 |
| 0.2 | 0.2 | risky_ps_old | 0.192000 | 0.060000 | 0.155576 | 0.060000 | 0.119000 | 0.010000 | 0.113897 | 0.268400 | 0.210000 | 0.272518 |

## Best PS Actual Params

| eta | epsilon | best_ps_method | eta_actual | epsilon_actual | eta_shared | gamma_shared | estimator | denominator_mode |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 0.01 | 0 | risky_ps | 0.01 | 0.0 | 0.05 | None | path_importance_weighted | path_prob |
| 0.01 | 0.02 | risky_ps | 0.01 | 0.02 | 0.05 | None | path_importance_weighted | path_prob |
| 0.01 | 0.05 | risky_ps | 0.01 | 0.05 | 0.05 | None | path_importance_weighted | path_prob |
| 0.01 | 0.1 | risky_ps | 0.01 | 0.1 | 0.05 | None | path_importance_weighted | path_prob |
| 0.01 | 0.2 | risky_ps | 0.01 | 0.2 | 0.05 | None | path_importance_weighted | path_prob |
| 0.02 | 0 | risky_ps | 0.02 | 0.0 | 0.05 | None | path_importance_weighted | path_prob |
| 0.02 | 0.02 | risky_ps | 0.02 | 0.02 | 0.05 | None | path_importance_weighted | path_prob |
| 0.02 | 0.05 | risky_ps | 0.02 | 0.05 | 0.05 | None | path_importance_weighted | path_prob |
| 0.02 | 0.1 | risky_ps | 0.02 | 0.1 | 0.05 | None | path_importance_weighted | path_prob |
| 0.02 | 0.2 | risky_ps | 0.02 | 0.2 | 0.05 | None | path_importance_weighted | path_prob |
| 0.05 | 0 | risky_ps_old | 0.05 | 0.0 | 0.05 | None | path_importance_weighted | path_prob |
| 0.05 | 0.02 | risky_ps_old | 0.05 | 0.02 | 0.05 | None | path_importance_weighted | path_prob |
| 0.05 | 0.05 | risky_ps_ix | 0.05 | 0.05 | 0.05 | 0.005 | exp3_ix | path_prob_plus_gamma |
| 0.05 | 0.1 | risky_ps_ix | 0.05 | 0.1 | 0.05 | 0.005 | exp3_ix | path_prob_plus_gamma |
| 0.05 | 0.2 | risky_ps_old | 0.05 | 0.2 | 0.05 | None | path_importance_weighted | path_prob |
| 0.1 | 0 | risky_ps_old | 0.1 | 0.0 | 0.1 | None | path_importance_weighted | path_prob |
| 0.1 | 0.02 | risky_ps | 0.1 | 0.02 | 0.05 | None | path_importance_weighted | path_prob |
| 0.1 | 0.05 | risky_ps_old | 0.1 | 0.05 | 0.1 | None | path_importance_weighted | path_prob |
| 0.1 | 0.1 | risky_ps_old | 0.1 | 0.1 | 0.1 | None | path_importance_weighted | path_prob |
| 0.1 | 0.2 | risky_ps_old | 0.1 | 0.2 | 0.1 | None | path_importance_weighted | path_prob |
| 0.2 | 0 | risky_ps_old | 0.2 | 0.0 | 0.2 | None | path_importance_weighted | path_prob |
| 0.2 | 0.02 | risky_ps_old | 0.2 | 0.02 | 0.2 | None | path_importance_weighted | path_prob |
| 0.2 | 0.05 | risky_ps_old | 0.2 | 0.05 | 0.2 | None | path_importance_weighted | path_prob |
| 0.2 | 0.1 | risky_ps_old | 0.2 | 0.1 | 0.2 | None | path_importance_weighted | path_prob |
| 0.2 | 0.2 | risky_ps_old | 0.2 | 0.2 | 0.2 | None | path_importance_weighted | path_prob |
