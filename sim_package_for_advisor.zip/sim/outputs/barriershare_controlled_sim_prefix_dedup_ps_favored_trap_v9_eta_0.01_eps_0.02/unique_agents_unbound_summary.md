# Unique-agent full-branching unbound controlled simulation

- tree_spec_role_mode: `spec_or_agent_id`
- num_paths: `440`
- duplicate_agent_count: `0`
- cross_prefix_duplicate_count: `0`

## Current Tree
| method | regret_per_t_mean | average_cost_mean | shared_path_fraction_mean | num_paths | horizon | seeds |
| --- | --- | --- | --- | --- | --- | --- |
| risky_ps | 0.25556155944510545 | 0.2706 | 0.9634 | 440 | 1000 | 5 |
| risky_ps_ix | 0.25836155944510547 | 0.2734 | 0.9650000000000001 | 440 | 1000 | 5 |
| risky_ps_old | 0.32596155944510546 | 0.341 | 0.9606 | 440 | 1000 | 5 |
| direct_multistage_exp3 | 0.3287615594451055 | 0.3438 | 0.9568 | 440 | 1000 | 5 |
| epsilon_exp3 | 0.3291615594451055 | 0.3442 | 0.9570000000000001 | 440 | 1000 | 5 |
| risky_ps_safe_conditional | 0.4153615594451055 | 0.4304 | 0.9536 | 440 | 1000 | 5 |
| risky_ps_safe_conditional_ix | 0.4195615594451055 | 0.4346 | 0.9532 | 440 | 1000 | 5 |
| risky_ps_direct_cost | 0.5011615594451054 | 0.5162 | 0.9495999999999999 | 440 | 1000 | 5 |
| random_path | 0.5933615594451054 | 0.6083999999999999 | 0.9269999999999999 | 440 | 1000 | 5 |
| naive_mixed | 0.7325615594451055 | 0.7476 | 1.0 | 440 | 1000 | 5 |

## Delta vs Old Unique-Agent Reference
| method | delta_regret_per_t | delta_terminal_proxy | delta_shared_path_fraction |
| --- | --- | --- | --- |
| risky_ps | 0.1524499256957145 | 0.1185657589030854 | -0.024599999999999844 |
| direct_multistage_exp3 | 0.2835157660740593 | 0.24963159928143017 | -0.03739999999999999 |
| epsilon_exp3 | 0.2291135877794901 | 0.19522942098686094 | -0.030999999999999805 |
| random_path | 0.11912205627459255 | 0.08523788948196342 | 0.0 |
| naive_mixed | 0.711708287815191 | 0.6778241210225618 | 0.0 |

## Delta vs Old Theory-Aligned Partial 4/5 Reference
| method | delta_regret_per_t | delta_terminal_proxy | delta_shared_path_fraction |
| --- | --- | --- | --- |
| risky_ps | -0.009807657485881693 | -0.04171975110909376 | 0.055440000000000156 |
| direct_multistage_exp3 | 0.2551758515090339 | 0.22326375788582178 | -0.023920000000000052 |
| epsilon_exp3 | 0.06379234251411836 | 0.03188024889090624 | 0.049040000000000195 |
| random_path | -0.03618773890104143 | -0.06809983252425345 | 0.12869999999999993 |
| naive_mixed | 0.38333695958722025 | 0.3514248659640082 | 0.97936 |

## Direct Answers
- Current risky_ps vs epsilon_exp3 gap: -0.073600. Old unique-agent gap: 0.003064. Old theory-aligned gap: 0.000000.
- Current risky_ps vs direct_multistage_exp3 gap: -0.073200. Old unique-agent gap: 0.057866. Old theory-aligned gap: 0.191784.
- Relative to old theory-aligned partial_4of5, the average risky_ps gap to epsilon/direct is smaller: current=-0.073400, old_theory=0.095892.
- Relative to the older bound unique-agent tree, the average risky_ps gap to epsilon/direct is smaller: current=-0.073400, old_unique=0.030465.
- PS-family ranking on this truly-unbound tree: 1. risky_ps (0.255562), 2. risky_ps_ix (0.258362), 3. risky_ps_safe_conditional (0.415362), 4. risky_ps_safe_conditional_ix (0.419562), 5. risky_ps_direct_cost (0.501162).
- naive_mixed rank is 10 with regret/T=0.732562.
- In `--tree-spec` mode, the synthetic cost role is now resolved in this order: explicit `cost_role`/`synthetic_role`/`latent_role` from the spec, then `agent_id` when role mode is unbound, and only `base_alias` in explicit compatibility mode.
- On this run the external-tree suffix family is keyed by the unique cost-role sequence plus gate pattern, so repeated `base_alias` strings no longer create cross-prefix latent-family reuse.
- This is still a structure ablation, not an apples-to-apples replacement for the old theory-aligned tree. The new tree keeps full branching and `num_paths=3125`, so any comparison to the old compact DAG must be read with that caveat.

## Old Unique-Agent Reference
| method | regret_per_t_mean | terminal_proxy_mean | shared_path_fraction_mean | num_paths | horizon | seeds |
| --- | --- | --- | --- | --- | --- | --- |
| naive_mixed | 0.0208532716299145 | 0.06977587897743817 | 1.0 | 440 | 1000 | 5 |
| direct_multistage_exp3 | 0.045245793371046165 | 0.09416840071856983 | 0.9942 | 440 | 1000 | 5 |
| epsilon_exp3 | 0.10004797166561541 | 0.14897057901313907 | 0.9879999999999999 | 440 | 1000 | 5 |
| risky_ps | 0.10311163374939095 | 0.1520342410969146 | 0.9879999999999999 | 440 | 1000 | 5 |
| random_path | 0.47423950317051283 | 0.5231621105180365 | 0.9269999999999999 | 440 | 1000 | 5 |

## Old Theory-Aligned Reference
| method | regret_per_t_mean | terminal_proxy_mean | shared_path_fraction_mean | num_paths | horizon | seeds |
| --- | --- | --- | --- | --- | --- | --- |
| direct_multistage_exp3 | 0.0735857079360716 | 0.12053624211417821 | 0.98072 | 3125 | 5000 | 10 |
| risky_ps | 0.26536921693098714 | 0.31231975110909377 | 0.9079599999999999 | 3125 | 5000 | 10 |
| epsilon_exp3 | 0.26536921693098714 | 0.31231975110909377 | 0.9079599999999999 | 3125 | 5000 | 10 |
| naive_mixed | 0.34922459985788523 | 0.39617513403599186 | 0.02064 | 3125 | 5000 | 10 |
| random_path | 0.6295492983461468 | 0.6764998325242534 | 0.7983 | 3125 | 5000 | 10 |
