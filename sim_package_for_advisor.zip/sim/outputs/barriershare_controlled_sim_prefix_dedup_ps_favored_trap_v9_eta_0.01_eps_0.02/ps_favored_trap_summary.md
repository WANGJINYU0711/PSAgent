# PS-favored trap controlled simulation

- tree_spec_cost_mode: `ps_favored_trap`
- trap_basin_definition: `{'b1': 'stage1_n4', 'b2': ['stage2_n4', 'stage2_n5']}`
- trap_basin_leaf_count: `64`
- trap_path_base_aliases: `['stage1_n4', 'stage2_n5', 'stage3_n5', 'stage4_n5', 'stage5_n5']`
- exact_trap_path_exists: `True`
- trap_switch_episode: `333`
- safe_basin_definition: `{'b3': ['stage3_n1', 'stage3_n2'], 'b4': 'stage4_n1', 'b5': ['stage5_n1', 'stage5_n2'], 'suffix_g': [0, 0, 0]}`
- cost_landscape_design: `v9_targeted_marginal_calibration`
- target_candidate_leaf_count: `16`
- target_good_leaf_count: `4`
- target_bad_leaf_count: `12`
- target_good_distribution_by_b3: `{'stage3_n1': 3, 'stage3_n2': 1}`
- target_good_distribution_by_b5: `{'stage5_n1': 3, 'stage5_n2': 1}`
- stage1_n3_stage2_n2_decoy_count: `13`
- stage1_n3_stage2_n3_decoy_count: `11`
- pre_calibration_stage1_n3_marginal: `{'stage2_n1': 0.42637129316555367, 'stage2_n2': 0.6540025002136509, 'stage2_n3': 0.647935864566299}`
- post_calibration_stage1_n3_marginal: `{'stage2_n1': 0.4755939145324865, 'stage2_n2': 0.5182668073633623, 'stage2_n3': 0.5227749251349743}`
- calibration_actions: `{'g2_decoy_count': 13, 'g3_decoy_count': 11, 'g1_target_bad_adjusted': True, 'g1_target_bad_adjusted_p_range': {'min': 0.9066924148854096, 'max': 0.9542547390354603}}`
- balancing_decoy_expected_p_range: `{'min': 0.205533480804671, 'max': 0.2735675591425511}`
- root_child_marginal_expected_cost: `{'stage1_n1': 0.5734704538809202, 'stage1_n2': 0.5765425449559543, 'stage1_n3': 0.5178892101829062, 'stage1_n4': 0.6429335070332866, 'stage1_n5': 0.7724433913151513}`
- stage2_marginal_expected_cost: `{'stage1_n1': {'stage2_n1': 0.6268635509449241, 'stage2_n2': 0.5658839541938062, 'stage2_n3': 0.5748569726654784}, 'stage1_n2': {'stage2_n1': 0.6220658552971902, 'stage2_n2': 0.5685851764553415, 'stage2_n3': 0.579306835195201}, 'stage1_n3': {'stage2_n1': 0.4755939145324865, 'stage2_n2': 0.5182668073633623, 'stage2_n3': 0.5227749251349743}}`
- exact_best_path: `['stage1_n3__from__root__c03', 'stage2_n1__from__n0003__c01', 'stage3_n2__from__n0012__c02', 'stage4_n1__from__n0042__c01', 'stage5_n1__from__n0121__c01']`
- exact_best_base_aliases: `['stage1_n3', 'stage2_n1', 'stage3_n2', 'stage4_n1', 'stage5_n1']`
- exact_best_expected_probability: `0.025`
- safe_basin_leaf_count: `24`
- safe_suffix_group_count: `4`
- oracle_best_leaf_type: `shared`
- oracle_best_is_shared: `True`
- target_ordering_met: `False`

## Method Results
| method | regret_per_t_mean | terminal_proxy_mean | shared_path_fraction_mean | trap_basin_fraction_mean | target_subtree_fraction_mean | target_good_fraction_mean | target_bad_fraction_mean | calibrated_decoy_fraction_mean | decoy_branch_fraction_mean | ordinary_safe_basin_fraction_mean | broad_safe_basin_fraction_mean | ps_favored_exact_best_hit_rate_mean | num_paths | horizon | seeds |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| risky_ps | 0.25556155944510545 | 0.2706 | 0.9634 | 0.08940000000000001 | 0.5514 | 0.5168 | 0.0346 | 0.057999999999999996 | 0.1898 | 0.0432 | 0.5946 | 0.1052 | 440 | 1000 | 5 |
| risky_ps_ix | 0.25836155944510547 | 0.2734 | 0.9650000000000001 | 0.0934 | 0.5498000000000001 | 0.5124000000000001 | 0.0374 | 0.062 | 0.1916 | 0.0412 | 0.591 | 0.0978 | 440 | 1000 | 5 |
| risky_ps_old | 0.32596155944510546 | 0.341 | 0.9606 | 0.1066 | 0.465 | 0.39980000000000004 | 0.06520000000000001 | 0.0754 | 0.236 | 0.0422 | 0.5072 | 0.1062 | 440 | 1000 | 5 |
| direct_multistage_exp3 | 0.3287615594451055 | 0.3438 | 0.9568 | 0.1122 | 0.46180000000000004 | 0.3944 | 0.0674 | 0.0784 | 0.2262 | 0.0502 | 0.512 | 0.11120000000000001 | 440 | 1000 | 5 |
| epsilon_exp3 | 0.3291615594451055 | 0.3442 | 0.9570000000000001 | 0.11200000000000002 | 0.45039999999999997 | 0.38580000000000003 | 0.0646 | 0.0842 | 0.2378 | 0.0474 | 0.49779999999999996 | 0.1038 | 440 | 1000 | 5 |
| risky_ps_safe_conditional | 0.4153615594451055 | 0.4304 | 0.9536 | 0.13040000000000002 | 0.3376 | 0.244 | 0.09359999999999999 | 0.11200000000000002 | 0.3134 | 0.0608 | 0.3984 | 0.0762 | 440 | 1000 | 5 |
| risky_ps_safe_conditional_ix | 0.4195615594451055 | 0.4346 | 0.9532 | 0.13040000000000002 | 0.3358 | 0.24159999999999998 | 0.09419999999999999 | 0.11280000000000001 | 0.315 | 0.0608 | 0.39659999999999995 | 0.0732 | 440 | 1000 | 5 |
| risky_ps_direct_cost | 0.5011615594451054 | 0.5162 | 0.9495999999999999 | 0.13679999999999998 | 0.2532 | 0.1212 | 0.132 | 0.1004 | 0.363 | 0.0692 | 0.3224 | 0.047599999999999996 | 440 | 1000 | 5 |
| random_path | 0.5933615594451054 | 0.6083999999999999 | 0.9269999999999999 | 0.08180000000000001 | 0.2426 | 0.06539999999999999 | 0.1772 | 0.05620000000000001 | 0.25680000000000003 | 0.061399999999999996 | 0.304 | 0.0164 | 440 | 1000 | 5 |
| naive_mixed | 0.7325615594451055 | 0.7476 | 1.0 | 0.0 | 0.9945999999999999 | 0.11279999999999998 | 0.8817999999999999 | 0.0 | 0.0028 | 0.0018000000000000002 | 0.9964000000000001 | 0.0 | 440 | 1000 | 5 |

## Ordering Checks
| risky_ps_better_than_epsilon_exp3 | epsilon_exp3_better_than_direct_multistage_exp3 | target_ordering_met |
| --- | --- | --- |
| True | False | False |

## Top-10 Leaf Expected Probabilities
| rank | mean_probability | leaf_type | family_label | base_aliases |
| --- | --- | --- | --- | --- |
| 1 | 0.015038440554894535 | shared | ps_favored_v7_target_good | ['stage1_n1', 'stage2_n1', 'stage3_n1', 'stage4_n1', 'stage5_n2'] |
| 2 | 0.01642850420907608 | shared | ps_favored_v7_target_good | ['stage1_n3', 'stage2_n1', 'stage3_n1', 'stage4_n1', 'stage5_n1'] |
| 3 | 0.02120274476996339 | shared | ps_favored_v7_target_good | ['stage1_n2', 'stage2_n1', 'stage3_n1', 'stage4_n1', 'stage5_n1'] |
| 4 | 0.025 | shared | ps_favored_exact_best_hash_selected | ['stage1_n3', 'stage2_n1', 'stage3_n2', 'stage4_n1', 'stage5_n1'] |
| 5 | 0.205533480804671 | shared | ps_favored_v9_balancing_candidate_base | ['stage1_n3', 'stage2_n3', 'stage3_n3', 'stage4_n2', 'stage5_n2'] |
| 6 | 0.2111916614685513 | shared | ps_favored_v9_balancing_candidate_base | ['stage1_n3', 'stage2_n2', 'stage3_n4', 'stage4_n3', 'stage5_n3'] |
| 7 | 0.21566042069561886 | shared | ps_favored_v9_balancing_candidate_base | ['stage1_n3', 'stage2_n3', 'stage3_n4', 'stage4_n4', 'stage5_n4'] |
| 8 | 0.21760795318316253 | shared | ps_favored_v9_balancing_candidate_base | ['stage1_n3', 'stage2_n2', 'stage3_n3', 'stage4_n3', 'stage5_n4'] |
| 9 | 0.2186029515038296 | shared | ps_favored_v9_balancing_candidate_base | ['stage1_n3', 'stage2_n3', 'stage3_n4', 'stage4_n4', 'stage5_n1'] |
| 10 | 0.2267353190749133 | shared | ps_favored_v9_balancing_candidate_base | ['stage1_n3', 'stage2_n2', 'stage3_n3', 'stage4_n3', 'stage5_n2'] |

## Top Safe Suffix Signatures
| signature | leaf_count | mean_probability |
| --- | --- | --- |
| ['stage3_n2', 'stage4_n1', 'stage5_n2'] | 8 | 0.6899800700429235 |
| ['stage3_n2', 'stage4_n1', 'stage5_n1'] | 8 | 0.5331935975047116 |
| ['stage3_n1', 'stage4_n1', 'stage5_n2'] | 4 | 0.6325098285973793 |
| ['stage3_n1', 'stage4_n1', 'stage5_n1'] | 4 | 0.43253164424306334 |
